import os
import yaml

_CONFIG_CACHE = None


def load_config(path=None):
    global _CONFIG_CACHE
    if _CONFIG_CACHE is not None:
        return _CONFIG_CACHE
    if path is None:
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        path = os.path.join(root, "config.yaml")
    with open(path) as f:
        cfg = yaml.safe_load(f)
    _CONFIG_CACHE = cfg
    return cfg
