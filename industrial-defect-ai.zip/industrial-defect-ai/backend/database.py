"""
Database Layer
================
Lightweight SQLite persistence for inspection history. No ORM - plain
sqlite3 with small helper functions, which keeps the one-command startup
dependency-free.
"""
import os
import sqlite3
import json
import time
import uuid
import threading

_LOCAL = threading.local()

SCHEMA = """
CREATE TABLE IF NOT EXISTS inspections (
    inspection_id   TEXT PRIMARY KEY,
    timestamp       TEXT NOT NULL,
    input_type      TEXT NOT NULL,
    product_type    TEXT,
    defect_count    INTEGER NOT NULL,
    defect_types    TEXT,
    max_severity    REAL,
    quality_grade   TEXT,
    status          TEXT,
    confidence      REAL,
    image_path      TEXT,
    annotated_path  TEXT,
    heatmap_path    TEXT,
    result_json     TEXT
);
"""


class Database:
    def __init__(self, db_path):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
        self._init_schema()

    def _connect(self):
        # sqlite3 connections aren't safe to share across threads (Flask's
        # dev server is multi-threaded), so keep one connection per thread.
        if not hasattr(_LOCAL, "conn") or getattr(_LOCAL, "db_path", None) != self.db_path:
            _LOCAL.conn = sqlite3.connect(self.db_path, check_same_thread=False)
            _LOCAL.conn.row_factory = sqlite3.Row
            _LOCAL.db_path = self.db_path
        return _LOCAL.conn

    def _init_schema(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute(SCHEMA)
        conn.commit()
        conn.close()

    def insert_inspection(self, record):
        conn = self._connect()
        record = dict(record)
        record.setdefault("inspection_id", f"INS-{uuid.uuid4().hex[:10].upper()}")
        record.setdefault("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))
        record["defect_types"] = json.dumps(record.get("defect_types", []))
        record["result_json"] = json.dumps(record.get("result_json", {}))
        cols = ["inspection_id", "timestamp", "input_type", "product_type", "defect_count",
                "defect_types", "max_severity", "quality_grade", "status", "confidence",
                "image_path", "annotated_path", "heatmap_path", "result_json"]
        vals = [record.get(c) for c in cols]
        placeholders = ",".join(["?"] * len(cols))
        conn.execute(f"INSERT INTO inspections ({','.join(cols)}) VALUES ({placeholders})", vals)
        conn.commit()
        return record["inspection_id"]

    def get_inspection(self, inspection_id):
        conn = self._connect()
        row = conn.execute("SELECT * FROM inspections WHERE inspection_id=?",
                            (inspection_id,)).fetchone()
        return self._row_to_dict(row) if row else None

    def list_inspections(self, search=None, status=None, sort="timestamp", order="desc", limit=200):
        conn = self._connect()
        query = "SELECT * FROM inspections WHERE 1=1"
        params = []
        if search:
            query += " AND (product_type LIKE ? OR inspection_id LIKE ? OR defect_types LIKE ?)"
            like = f"%{search}%"
            params += [like, like, like]
        if status:
            query += " AND status = ?"
            params.append(status)
        sort = sort if sort in ("timestamp", "max_severity", "defect_count", "quality_grade") else "timestamp"
        order = "DESC" if str(order).lower() != "asc" else "ASC"
        query += f" ORDER BY {sort} {order} LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def delete_inspection(self, inspection_id):
        conn = self._connect()
        conn.execute("DELETE FROM inspections WHERE inspection_id=?", (inspection_id,))
        conn.commit()

    def clear_all(self):
        """Wipe every inspection record so dashboard/analytics counts reset to zero."""
        conn = self._connect()
        conn.execute("DELETE FROM inspections")
        conn.commit()

    def dashboard_stats(self):
        conn = self._connect()
        total = conn.execute("SELECT COUNT(*) c FROM inspections").fetchone()["c"]
        defects = conn.execute("SELECT COALESCE(SUM(defect_count),0) c FROM inspections").fetchone()["c"]
        passed = conn.execute("SELECT COUNT(*) c FROM inspections WHERE status='PASS'").fetchone()["c"]
        rejected = conn.execute("SELECT COUNT(*) c FROM inspections WHERE status='REJECT'").fetchone()["c"]
        avg_sev = conn.execute("SELECT COALESCE(AVG(max_severity),0) a FROM inspections").fetchone()["a"]
        pass_rate = round(100.0 * passed / total, 1) if total else 0.0

        by_type = conn.execute(
            "SELECT defect_types FROM inspections WHERE defect_count > 0"
        ).fetchall()
        type_counter = {}
        for row in by_type:
            for t in json.loads(row["defect_types"] or "[]"):
                type_counter[t] = type_counter.get(t, 0) + 1

        by_grade = conn.execute(
            "SELECT quality_grade, COUNT(*) c FROM inspections GROUP BY quality_grade"
        ).fetchall()
        grade_counter = {r["quality_grade"]: r["c"] for r in by_grade}

        timeline = conn.execute(
            "SELECT substr(timestamp,1,10) day, COUNT(*) c, "
            "SUM(CASE WHEN status='REJECT' THEN 1 ELSE 0 END) rejects "
            "FROM inspections GROUP BY day ORDER BY day"
        ).fetchall()
        timeline_data = [{"date": r["day"], "count": r["c"], "rejects": r["rejects"]} for r in timeline]

        severity_buckets = {"0-20": 0, "21-45": 0, "46-75": 0, "76-100": 0}
        sev_rows = conn.execute("SELECT max_severity FROM inspections").fetchall()
        for r in sev_rows:
            v = r["max_severity"] or 0
            if v <= 20:
                severity_buckets["0-20"] += 1
            elif v <= 45:
                severity_buckets["21-45"] += 1
            elif v <= 75:
                severity_buckets["46-75"] += 1
            else:
                severity_buckets["76-100"] += 1

        return {
            "total_inspections": total,
            "defects_detected": defects,
            "pass_rate": pass_rate,
            "average_severity": round(avg_sev, 1),
            "rejected": rejected,
            "defects_by_type": type_counter,
            "grades": grade_counter,
            "timeline": timeline_data,
            "severity_distribution": severity_buckets,
        }

    @staticmethod
    def _row_to_dict(row):
        d = dict(row)
        d["defect_types"] = json.loads(d.get("defect_types") or "[]")
        d["result_json"] = json.loads(d.get("result_json") or "{}")
        return d
