/* ==========================================================================
   DEFECTAI Frontend Application
   Vanilla JS SPA — no build step, no external CDN dependency.
   ========================================================================== */

const API = "";

// ---------------------------------------------------------------------
// Small utilities
// ---------------------------------------------------------------------
async function api(path, opts = {}) {
  // cache: "no-store" guarantees GET requests (e.g. dashboard refresh) always
  // hit the server instead of returning a stale cached response.
  const res = await fetch(API + path, { cache: "no-store", ...opts });
  let data;
  try { data = await res.json(); } catch (e) { data = null; }
  if (!res.ok) {
    const msg = (data && data.error) ? data.error : `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

// ---------------------------------------------------------------------
// Icons — minimal inline SVG set (stroke-based, no emoji, no external deps)
// ---------------------------------------------------------------------
const ICONS = {
  grid: '<rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline>',
  video: '<path d="M23 7l-7 5 7 5V7z"></path><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>',
  camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle>',
  clipboard: '<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>',
  barChart: '<line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>',
  cpu: '<rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line>',
  settings: '<circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>',
  refresh: '<polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>',
  zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>',
  alertTriangle: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line>',
  checkCircle: '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline>',
  trendingDown: '<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"></polyline><polyline points="17 18 23 18 23 12"></polyline>',
  trendingUp: '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline>',
  xCircle: '<circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>',
  film: '<rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect><line x1="7" y1="2" x2="7" y2="22"></line><line x1="17" y1="2" x2="17" y2="22"></line><line x1="2" y1="12" x2="22" y2="12"></line><line x1="2" y1="7" x2="7" y2="7"></line><line x1="2" y1="17" x2="7" y2="17"></line><line x1="17" y1="17" x2="22" y2="17"></line><line x1="17" y1="7" x2="22" y2="7"></line>',
  fileText: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline>',
  play: '<polygon points="5 3 19 12 5 21 5 3"></polygon>',
  pause: '<rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect>',
  square: '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>',
  package: '<path d="M16.5 9.4L7.5 4.21"></path><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line>',
  activity: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>',
  tag: '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line>',
  target: '<circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="6"></circle><circle cx="12" cy="12" r="2"></circle>',
  crosshair: '<circle cx="12" cy="12" r="10"></circle><line x1="22" y1="12" x2="18" y2="12"></line><line x1="6" y1="12" x2="2" y2="12"></line><line x1="12" y1="6" x2="12" y2="2"></line><line x1="12" y1="22" x2="12" y2="18"></line>',
  sliders: '<line x1="4" y1="21" x2="4" y2="14"></line><line x1="4" y1="10" x2="4" y2="3"></line><line x1="12" y1="21" x2="12" y2="12"></line><line x1="12" y1="8" x2="12" y2="3"></line><line x1="20" y1="21" x2="20" y2="16"></line><line x1="20" y1="12" x2="20" y2="3"></line><line x1="1" y1="14" x2="7" y2="14"></line><line x1="9" y1="8" x2="15" y2="8"></line><line x1="17" y1="16" x2="23" y2="16"></line>',
  inbox: '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path>',
};

function icon(name, size = 16) {
  const paths = ICONS[name] || "";
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
}

function el(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

function toast(message, type = "info") {
  const wrap = document.getElementById("toast-wrap");
  const t = el(`<div class="toast ${type}">${escapeHtml(message)}</div>`);
  wrap.appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

function escapeHtml(s) {
  if (s === null || s === undefined) return "";
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function statusBadge(status) {
  const cls = { PASS: "pass", REVIEW: "review", REJECT: "reject" }[status] || "neutral";
  return `<span class="badge ${cls}">${escapeHtml(status || "-")}</span>`;
}

function severityBadge(level) {
  const cls = (level || "").toLowerCase();
  return `<span class="badge ${cls || "neutral"}">${escapeHtml(level || "-")}</span>`;
}

function pct(x) { return (x === undefined || x === null) ? "-" : `${(x).toFixed(1)}%`; }
function fmtNum(x) { return (x === undefined || x === null) ? "-" : x; }

const COLORS = {
  accent: "#4f8cff", green: "#29c46b", amber: "#f5a524", red: "#f5455c",
  purple: "#8b6bff", grid: "#232b36", text: "#9aa7b5",
  palette: ["#4f8cff", "#8b6bff", "#29c46b", "#f5a524", "#f5455c", "#25b8c4", "#e069c9"],
};

// ---------------------------------------------------------------------
// Minimal canvas chart helpers (no external chart library)
// ---------------------------------------------------------------------
function setupCanvas(canvas) {
  const ratio = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const w = rect.width || canvas.parentElement.clientWidth || 400;
  const h = canvas.height / (canvas._logicalRatio || 1) || 220;
  canvas.width = w * ratio;
  canvas.height = (canvas.dataset.h ? parseInt(canvas.dataset.h) : 220) * ratio;
  canvas.style.width = w + "px";
  canvas.style.height = (canvas.dataset.h ? parseInt(canvas.dataset.h) : 220) + "px";
  const ctx = canvas.getContext("2d");
  ctx.scale(ratio, ratio);
  return { ctx, w, h: canvas.dataset.h ? parseInt(canvas.dataset.h) : 220 };
}

function drawBarChart(canvas, labels, values, opts = {}) {
  const { ctx, w, h } = setupCanvas(canvas);
  ctx.clearRect(0, 0, w, h);
  const padL = 34, padB = 26, padT = 14, padR = 10;
  const chartW = w - padL - padR, chartH = h - padT - padB;
  const maxVal = Math.max(1, ...values) * 1.15;
  const barGap = 14;
  const barW = Math.max(6, (chartW - barGap * (values.length - 1)) / values.length);

  ctx.strokeStyle = COLORS.grid; ctx.lineWidth = 1;
  for (let i = 0; i <= 3; i++) {
    const y = padT + chartH - (chartH * i) / 3;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
    ctx.fillStyle = COLORS.text; ctx.font = "10px sans-serif"; ctx.textAlign = "right";
    ctx.fillText(Math.round((maxVal * i) / 3), padL - 6, y + 3);
  }

  values.forEach((v, i) => {
    const x = padL + i * (barW + barGap);
    const barH = (v / maxVal) * chartH;
    const y = padT + chartH - barH;
    const grad = ctx.createLinearGradient(0, y, 0, y + barH);
    const color = (opts.colors && opts.colors[i]) || opts.color || COLORS.accent;
    grad.addColorStop(0, color);
    grad.addColorStop(1, color + "55");
    ctx.fillStyle = grad;
    roundRect(ctx, x, y, barW, Math.max(2, barH), 5);
    ctx.fill();
    ctx.fillStyle = COLORS.text; ctx.font = "10px sans-serif"; ctx.textAlign = "center";
    const label = labels[i] !== undefined ? String(labels[i]) : "";
    ctx.fillText(label.length > 10 ? label.slice(0, 9) + "\u2026" : label, x + barW / 2, h - 8);
  });
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawLineChart(canvas, labels, series) {
  // series: [{name, values, color}]
  const { ctx, w, h } = setupCanvas(canvas);
  ctx.clearRect(0, 0, w, h);
  const padL = 34, padB = 24, padT = 14, padR = 10;
  const chartW = w - padL - padR, chartH = h - padT - padB;
  const allVals = series.flatMap(s => s.values);
  const maxVal = Math.max(1, ...allVals) * 1.2;
  const n = labels.length;

  ctx.strokeStyle = COLORS.grid; ctx.lineWidth = 1;
  for (let i = 0; i <= 3; i++) {
    const y = padT + chartH - (chartH * i) / 3;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
    ctx.fillStyle = COLORS.text; ctx.font = "10px sans-serif"; ctx.textAlign = "right";
    ctx.fillText(Math.round((maxVal * i) / 3), padL - 6, y + 3);
  }

  series.forEach(s => {
    ctx.beginPath();
    s.values.forEach((v, i) => {
      const x = padL + (n <= 1 ? 0 : (chartW * i) / (n - 1));
      const y = padT + chartH - (v / maxVal) * chartH;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = s.color; ctx.lineWidth = 2.4; ctx.lineJoin = "round"; ctx.stroke();

    s.values.forEach((v, i) => {
      const x = padL + (n <= 1 ? 0 : (chartW * i) / (n - 1));
      const y = padT + chartH - (v / maxVal) * chartH;
      ctx.beginPath(); ctx.arc(x, y, 2.6, 0, 7); ctx.fillStyle = s.color; ctx.fill();
    });
  });

  ctx.fillStyle = COLORS.text; ctx.font = "10px sans-serif"; ctx.textAlign = "center";
  labels.forEach((lbl, i) => {
    if (n > 8 && i % Math.ceil(n / 8) !== 0) return;
    const x = padL + (n <= 1 ? 0 : (chartW * i) / (n - 1));
    ctx.fillText(String(lbl).slice(5), x, h - 6);
  });
}

// ---------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------
const PAGE_TITLES = {
  dashboard: "Dashboard", image: "Image Inspection", video: "Video Inspection",
  live: "Live Camera Inspection", results: "Inspection Results", analytics: "Analytics",
  dataset: "Dataset Management", model: "Model Information", settings: "Settings",
};

const LOADERS = {
  dashboard: loadDashboard, image: loadImagePage, video: loadVideoPage,
  live: loadLivePage, results: loadResultsPage, analytics: loadAnalyticsPage,
  dataset: loadDatasetPage, model: loadModelPage, settings: loadSettingsPage,
};

let currentRoute = null;

function navigate(route) {
  if (!LOADERS[route]) route = "dashboard";
  if (currentRoute === "live" && route !== "live") stopCamera();
  currentRoute = route;
  document.querySelectorAll(".nav-item").forEach(n => n.classList.toggle("active", n.dataset.route === route));
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === "page-" + route));
  document.getElementById("page-title").textContent = PAGE_TITLES[route];
  window.location.hash = route;
  LOADERS[route]();
}

document.querySelectorAll(".nav-item[data-route]").forEach(item => {
  item.addEventListener("click", () => navigate(item.dataset.route));
});

async function checkHealth() {
  const pill = document.getElementById("system-status");
  try {
    const h = await api("/api/health");
    pill.className = "status-pill";
    pill.innerHTML = `<span class="status-dot"></span> System Online \u00b7 ${h.device}`;
  } catch (e) {
    pill.className = "status-pill offline";
    pill.innerHTML = `<span class="status-dot"></span> System Offline`;
  }
}

// ---------------------------------------------------------------------
// DASHBOARD
// ---------------------------------------------------------------------
async function loadDashboard() {
  const body = document.getElementById("dashboard-body");
  try {
    const [stats, insp] = await Promise.all([
      api("/api/dashboard"),
      api("/api/inspections?sort=timestamp&order=desc"),
    ]);
    const recent = insp.inspections.slice(0, 8);

    body.innerHTML = `
      <div class="grid grid-5" style="margin-bottom:18px;">
        ${kpiCard("Total Inspections", stats.total_inspections, icon("barChart", 20))}
        ${kpiCard("Defects Detected", stats.defects_detected, icon("alertTriangle", 20))}
        ${kpiCard("Pass Rate", stats.pass_rate + "%", icon("checkCircle", 20))}
        ${kpiCard("Average Severity", stats.average_severity, icon("trendingDown", 20))}
        ${kpiCard("Rejected", stats.rejected, icon("xCircle", 20))}
      </div>
      <div class="grid grid-2" style="margin-bottom:18px;">
        <div class="card chart-card">
          <div class="section-title">Defects by Type</div>
          <canvas id="chart-by-type" data-h="220"></canvas>
        </div>
        <div class="card chart-card">
          <div class="section-title">Severity Distribution</div>
          <canvas id="chart-severity" data-h="220"></canvas>
        </div>
      </div>
      <div class="grid grid-2" style="margin-bottom:18px;">
        <div class="card chart-card">
          <div class="section-title">Inspections Over Time</div>
          <canvas id="chart-timeline" data-h="200"></canvas>
        </div>
        <div class="card chart-card">
          <div class="section-title">Quality Grades</div>
          <canvas id="chart-grades" data-h="200"></canvas>
        </div>
      </div>
      <div class="card">
        <div class="section-title">Recent Inspections <span class="muted">latest 8</span></div>
        ${recentTable(recent)}
      </div>
    `;

    const byType = stats.defects_by_type || {};
    drawBarChart(document.getElementById("chart-by-type"), Object.keys(byType), Object.values(byType),
      { colors: COLORS.palette });

    const sevDist = stats.severity_distribution || {};
    drawBarChart(document.getElementById("chart-severity"), Object.keys(sevDist), Object.values(sevDist),
      { colors: [COLORS.green, COLORS.amber, "#ff8a3d", COLORS.red] });

    const timeline = stats.timeline || [];
    drawLineChart(document.getElementById("chart-timeline"), timeline.map(t => t.date), [
      { name: "Inspections", values: timeline.map(t => t.count), color: COLORS.accent },
      { name: "Rejects", values: timeline.map(t => t.rejects), color: COLORS.red },
    ]);

    const grades = stats.grades || {};
    drawBarChart(document.getElementById("chart-grades"), Object.keys(grades), Object.values(grades),
      { colors: [COLORS.green, COLORS.accent, COLORS.amber, COLORS.red] });

  } catch (e) {
    body.innerHTML = emptyState("Could not load dashboard: " + e.message);
  }
}

function kpiCard(label, value, icon) {
  return `<div class="card kpi-card">
    <span class="kpi-icon">${icon}</span>
    <div class="kpi-label">${label}</div>
    <div class="kpi-value">${value}</div>
  </div>`;
}

function recentTable(rows) {
  if (!rows.length) return emptyState("No inspections yet. Run your first inspection to see it here.");
  return `<table class="data-table"><thead><tr>
    <th>ID</th><th>Time</th><th>Type</th><th>Product</th><th>Defects</th><th>Severity</th><th>Grade</th><th>Status</th>
  </tr></thead><tbody>
    ${rows.map(r => `<tr>
      <td class="mono">${r.inspection_id}</td>
      <td>${r.timestamp}</td>
      <td>${escapeHtml(r.input_type)}</td>
      <td>${escapeHtml((r.product_type || "-").replace(/_/g, " "))}</td>
      <td>${r.defect_count}</td>
      <td>${r.max_severity}/100</td>
      <td>${r.quality_grade}</td>
      <td>${statusBadge(r.status)}</td>
    </tr>`).join("")}
  </tbody></table>`;
}

function emptyState(msg) {
  return `<div class="empty-state"><div class="es-icon">${icon("inbox", 30)}</div>${escapeHtml(msg)}</div>`;
}

document.getElementById("btn-refresh-dashboard").addEventListener("click", async () => {
  const btn = document.getElementById("btn-refresh-dashboard");
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner"></span> Refreshing\u2026`;
  // Clear the old KPI values and charts immediately so stale numbers never
  // linger on screen while the new data is being fetched.
  document.getElementById("dashboard-body").innerHTML = `<div class="skeleton" style="height:400px;"></div>`;
  try {
    await loadDashboard();
  } finally {
    btn.disabled = false;
    btn.innerHTML = original;
  }
});

document.getElementById("btn-reset-dashboard").addEventListener("click", async () => {
  const confirmed = window.confirm(
    "This permanently deletes every inspection record and resets all dashboard counts to zero. This cannot be undone. Continue?"
  );
  if (!confirmed) return;
  const btn = document.getElementById("btn-reset-dashboard");
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner"></span> Resetting\u2026`;
  try {
    await api("/api/inspections", { method: "DELETE" });
    document.getElementById("dashboard-body").innerHTML = `<div class="skeleton" style="height:400px;"></div>`;
    await loadDashboard();
    toast("All inspection data cleared", "success");
  } catch (e) {
    toast(e.message, "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = original;
  }
});
document.getElementById("btn-try-demo").addEventListener("click", async () => {
  const btn = document.getElementById("btn-try-demo");
  btn.disabled = true; btn.innerHTML = `<span class="spinner"></span> Running demo\u2026`;
  try {
    const result = await api("/api/inspect/demo", { method: "POST" });
    navigate("image");
    renderImageResult(result);
    toast("Demo inspection complete", "success");
  } catch (e) {
    toast(e.message, "error");
  } finally {
    btn.disabled = false; btn.innerHTML = `${icon("zap")} Try Demo Inspection`;
  }
});

// ---------------------------------------------------------------------
// IMAGE INSPECTION
// ---------------------------------------------------------------------
function loadImagePage() {
  const body = document.getElementById("image-body");
  body.innerHTML = `
    <div class="grid grid-2" style="align-items:start;">
      <div class="card">
        <div class="section-title">Upload Product Image</div>
        <div class="dropzone" id="img-dropzone">
          <div class="dz-icon">${icon("image", 34)}</div>
          <div class="dz-title">Drag & drop an image, or click to browse</div>
          <div class="dz-sub">JPG, JPEG, PNG, WEBP</div>
          <input type="file" id="img-input" accept=".jpg,.jpeg,.png,.webp" style="display:none;">
        </div>
        <div class="field" style="margin-top:16px;">
          <label>Product Category</label>
          <select id="img-category">${categoryOptions()}</select>
        </div>
        <div id="img-preview-wrap"></div>
        <button class="btn primary" id="img-submit" style="width:100%; margin-top:10px;" disabled>Run Inspection</button>
      </div>
      <div id="image-result"><div class="empty-state"><div class="es-icon">${icon("eye", 30)}</div>Upload an image to see the AI decision here.</div></div>
    </div>
  `;

  const dz = document.getElementById("img-dropzone");
  const input = document.getElementById("img-input");
  let selectedFile = null;

  dz.addEventListener("click", () => input.click());
  dz.addEventListener("dragover", e => { e.preventDefault(); dz.classList.add("drag"); });
  dz.addEventListener("dragleave", () => dz.classList.remove("drag"));
  dz.addEventListener("drop", e => {
    e.preventDefault(); dz.classList.remove("drag");
    if (e.dataTransfer.files.length) { selectedFile = e.dataTransfer.files[0]; onFileSelected(); }
  });
  input.addEventListener("change", () => { if (input.files.length) { selectedFile = input.files[0]; onFileSelected(); } });

  function onFileSelected() {
    document.getElementById("img-submit").disabled = false;
    const url = URL.createObjectURL(selectedFile);
    document.getElementById("img-preview-wrap").innerHTML =
      `<div class="image-compare" style="margin-top:14px;"><img src="${url}"></div>`;
  }

  document.getElementById("img-submit").addEventListener("click", async () => {
    if (!selectedFile) return;
    const btn = document.getElementById("img-submit");
    btn.disabled = true; btn.innerHTML = `<span class="spinner"></span> Analyzing\u2026`;
    document.getElementById("image-result").innerHTML = resultSkeleton();
    const fd = new FormData();
    fd.append("file", selectedFile);
    fd.append("product_type", document.getElementById("img-category").value);
    try {
      const result = await api("/api/inspect/image", { method: "POST", body: fd });
      renderImageResult(result);
      toast("Inspection complete", "success");
    } catch (e) {
      document.getElementById("image-result").innerHTML = emptyState("Inspection failed: " + e.message);
      toast(e.message, "error");
    } finally {
      btn.disabled = false; btn.innerHTML = "Run Inspection";
    }
  });
}

function categoryOptions() {
  const cats = ["metal_panel","automotive_part","pipe","machine_component","electronic_housing",
    "bottle","sheet_metal","bearing","gear","industrial_component"];
  return cats.map(c => `<option value="${c}">${c.replace(/_/g," ").replace(/\b\w/g, l=>l.toUpperCase())}</option>`).join("");
}

function resultSkeleton() {
  return `<div class="card"><div class="skeleton" style="height:60px;margin-bottom:14px;"></div>
  <div class="skeleton" style="height:260px;margin-bottom:14px;"></div>
  <div class="skeleton" style="height:120px;"></div></div>`;
}

function renderImageResult(result) {
  const target = document.getElementById("image-result") || document.getElementById("video-body");
  const statusClass = (result.status || "pass").toLowerCase();
  const views = {
    Original: result.image_path_url,
    Detection: result.annotated_path_url,
    Heatmap: result.heatmap_path_url,
  };

  target.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div class="decision-hero ${statusClass}">
        <div>
          <div class="decision-status ${statusClass}">${result.status}</div>
          <div class="muted" style="margin-top:4px;">${escapeHtml((result.product_type||"").replace(/_/g," "))} \u00b7 ${result.inspection_id}</div>
        </div>
        <div class="decision-meta">
          <div><div class="m-label">Grade</div><div class="m-value">${result.quality_grade}</div></div>
          <div><div class="m-label">Defects</div><div class="m-value">${result.defect_count}</div></div>
          <div><div class="m-label">Max Severity</div><div class="m-value">${result.max_severity}/100</div></div>
          <div><div class="m-label">Avg Confidence</div><div class="m-value">${result.average_confidence}%</div></div>
        </div>
      </div>
    </div>

    <div class="card" style="margin-bottom:16px;">
      <div class="view-toggle" id="view-toggle">
        ${Object.keys(views).map((k,i) => `<button data-view="${k}" class="${i===1?'active':''}">${k}</button>`).join("")}
        <button data-view="Explanation">Explanation</button>
      </div>
      <div id="view-content"></div>
    </div>

    <div class="card">
      <div class="section-title">Defect Analysis</div>
      ${defectTable(result.detections)}
    </div>

    <div style="margin-top:14px; display:flex; gap:10px;">
      <button class="btn primary" id="btn-gen-report">${icon("fileText")} Generate Inspection Report</button>
    </div>
  `;

  function renderView(view) {
    const content = document.getElementById("view-content");
    if (view === "Explanation") {
      content.innerHTML = `<div class="explanation-box">${escapeHtml(result.explanation_text)}</div>`;
    } else {
      content.innerHTML = `<div class="image-compare"><img src="${views[view]}"></div>`;
    }
  }
  renderView("Detection");
  document.querySelectorAll("#view-toggle button").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#view-toggle button").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      renderView(btn.dataset.view);
    });
  });

  const reportBtn = document.getElementById("btn-gen-report");
  if (reportBtn) {
    reportBtn.addEventListener("click", () => {
      window.open(`/api/report/${result.inspection_id}`, "_blank");
    });
  }
}

function defectTable(detections) {
  if (!detections || !detections.length) {
    return emptyState("No defects detected \u2014 product passed inspection.");
  }
  return `<table class="data-table"><thead><tr>
    <th>Type</th><th>Confidence</th><th>Severity</th><th>Area</th><th>Location (bbox)</th><th>Impact</th>
  </tr></thead><tbody>
    ${detections.map(d => `<tr>
      <td>${escapeHtml((d.defect||"").toUpperCase())}</td>
      <td>${(d.confidence*100).toFixed(1)}%</td>
      <td>${severityBadge(d.severity_level)} ${d.severity}/100</td>
      <td>${pct(d.area_percentage)}</td>
      <td class="mono">[${d.bbox.join(", ")}]</td>
      <td>${d.severity_breakdown ? d.severity_breakdown.components.defect_type_risk.toFixed(0) : "-"}</td>
    </tr>`).join("")}
  </tbody></table>`;
}

// ---------------------------------------------------------------------
// VIDEO INSPECTION
// ---------------------------------------------------------------------
function loadVideoPage() {
  const body = document.getElementById("video-body");
  body.innerHTML = `
    <div class="grid grid-2" style="align-items:start;">
      <div class="card">
        <div class="section-title">Upload Product Video</div>
        <div class="dropzone" id="vid-dropzone">
          <div class="dz-icon">${icon("video", 34)}</div>
          <div class="dz-title">Drag & drop a video, or click to browse</div>
          <div class="dz-sub">MP4, AVI, MOV, MKV, WEBM</div>
          <input type="file" id="vid-input" accept=".mp4,.avi,.mov,.mkv,.webm" style="display:none;">
        </div>
        <div class="field" style="margin-top:16px;">
          <label>Product Category</label>
          <select id="vid-category">${categoryOptions()}</select>
        </div>
        <div id="vid-filename" class="muted" style="margin:10px 0; font-size:12.5px;"></div>
        <button class="btn primary" id="vid-submit" style="width:100%;" disabled>Run Video Inspection</button>
        <div id="vid-progress" style="margin-top:14px; display:none;">
          <div class="progress-track"><div class="progress-fill" id="vid-progress-fill" style="width:8%;"></div></div>
          <div class="muted" style="font-size:12px; margin-top:8px;">Processing frames on CPU \u2014 this can take a moment for longer clips\u2026</div>
        </div>
      </div>
      <div id="video-result"><div class="empty-state"><div class="es-icon">${icon("film", 30)}</div>Upload a video to see frame-by-frame inspection results.</div></div>
    </div>
  `;

  const dz = document.getElementById("vid-dropzone");
  const input = document.getElementById("vid-input");
  let selectedFile = null;

  dz.addEventListener("click", () => input.click());
  dz.addEventListener("dragover", e => { e.preventDefault(); dz.classList.add("drag"); });
  dz.addEventListener("dragleave", () => dz.classList.remove("drag"));
  dz.addEventListener("drop", e => {
    e.preventDefault(); dz.classList.remove("drag");
    if (e.dataTransfer.files.length) { selectedFile = e.dataTransfer.files[0]; onFileSelected(); }
  });
  input.addEventListener("change", () => { if (input.files.length) { selectedFile = input.files[0]; onFileSelected(); } });

  function onFileSelected() {
    document.getElementById("vid-submit").disabled = false;
    document.getElementById("vid-filename").textContent = "Selected: " + selectedFile.name;
  }

  document.getElementById("vid-submit").addEventListener("click", async () => {
    if (!selectedFile) return;
    const btn = document.getElementById("vid-submit");
    btn.disabled = true; btn.innerHTML = `<span class="spinner"></span> Processing\u2026`;
    document.getElementById("vid-progress").style.display = "block";
    const fill = document.getElementById("vid-progress-fill");
    let p = 8;
    const timer = setInterval(() => { p = Math.min(92, p + Math.random() * 6); fill.style.width = p + "%"; }, 500);

    const fd = new FormData();
    fd.append("file", selectedFile);
    fd.append("product_type", document.getElementById("vid-category").value);
    try {
      const result = await api("/api/inspect/video", { method: "POST", body: fd });
      clearInterval(timer); fill.style.width = "100%";
      renderVideoResult(result);
      toast("Video inspection complete", "success");
    } catch (e) {
      clearInterval(timer);
      document.getElementById("video-result").innerHTML = emptyState("Video inspection failed: " + e.message);
      toast(e.message, "error");
    } finally {
      btn.disabled = false; btn.innerHTML = "Run Video Inspection";
      setTimeout(() => { document.getElementById("vid-progress").style.display = "none"; }, 600);
    }
  });
}

function renderVideoResult(result) {
  const target = document.getElementById("video-result");
  const statusClass = (result.status || "pass").toLowerCase();
  const typeCounts = result.defect_type_counts || {};
  target.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div class="decision-hero ${statusClass}">
        <div>
          <div class="decision-status ${statusClass}">${result.status}</div>
          <div class="muted" style="margin-top:4px;">${result.inspection_id}</div>
        </div>
        <div class="decision-meta">
          <div><div class="m-label">Grade</div><div class="m-value">${result.quality_grade}</div></div>
          <div><div class="m-label">Frames Processed</div><div class="m-value">${result.frames_processed}/${result.frames_total}</div></div>
          <div><div class="m-label">Defects Found</div><div class="m-value">${result.defects_found}</div></div>
          <div><div class="m-label">Max Severity</div><div class="m-value">${result.max_severity}/100</div></div>
        </div>
      </div>
    </div>
    ${result.annotated_video_url ? `<div class="card" style="margin-bottom:16px;">
      <div class="section-title">Annotated Video</div>
      <video src="${result.annotated_video_url}" controls style="width:100%;border-radius:10px;"></video>
    </div>` : ""}
    <div class="card" style="margin-bottom:16px;">
      <div class="section-title">Defects by Type</div>
      <div class="tag-row">${Object.entries(typeCounts).map(([k,v]) => `<span class="pill-tag">${k}: <b>${v}</b></span>`).join("") || "None"}</div>
    </div>
    <div class="card" style="margin-bottom:16px;">
      <div class="section-title">Explanation</div>
      <div class="explanation-box">${escapeHtml(result.explanation_text)}</div>
    </div>
    <button class="btn primary" onclick="window.open('/api/report/${result.inspection_id}','_blank')">${icon('fileText')} Generate Inspection Report</button>
  `;
}

// ---------------------------------------------------------------------
// LIVE CAMERA
// ---------------------------------------------------------------------
let cameraStream = null;
let cameraTimer = null;
let cameraPaused = false;

function loadLivePage() {
  const body = document.getElementById("live-body");
  body.innerHTML = `
    <div class="grid grid-2" style="align-items:start;">
      <div>
        <div class="camera-wrap" style="position:relative;">
          <div class="camera-topbar">
            <div class="live-badge"><span class="pulse"></span> <span id="live-indicator">CAMERA OFF</span></div>
            <div class="camera-stats">
              <span>DEFECTS: <b id="stat-defects">0</b></span>
              <span>SEVERITY: <b id="stat-severity">0</b></span>
              <span>GRADE: <b id="stat-grade">-</b></span>
              <span>STATUS: <b id="stat-status">-</b></span>
            </div>
          </div>
          <video id="camera-video" autoplay muted playsinline></video>
          <canvas id="camera-overlay" class="overlay"></canvas>
        </div>
        <div class="camera-controls">
          <button class="btn primary" id="cam-start">${icon("play")} Start Camera</button>
          <button class="btn" id="cam-pause" disabled>${icon("pause")} Pause</button>
          <button class="btn" id="cam-capture" disabled>${icon("camera")} Capture</button>
          <button class="btn danger" id="cam-stop" disabled>${icon("square")} Stop Camera</button>
        </div>
        <div class="field" style="margin-top:16px;">
          <label>Product Category</label>
          <select id="cam-category">${categoryOptions()}</select>
        </div>
      </div>
      <div id="live-result"><div class="empty-state"><div class="es-icon">${icon("camera", 30)}</div>Start the camera to begin live inspection. Click Capture to save a full inspection result.</div></div>
    </div>
  `;

  document.getElementById("cam-start").addEventListener("click", startCamera);
  document.getElementById("cam-pause").addEventListener("click", togglePause);
  document.getElementById("cam-stop").addEventListener("click", stopCamera);
  document.getElementById("cam-capture").addEventListener("click", captureFrame);
}

async function startCamera() {
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
  } catch (e) {
    toast("Camera unavailable \u2014 please check browser camera permissions and try again.", "error");
    return;
  }
  const video = document.getElementById("camera-video");
  video.srcObject = cameraStream;
  document.getElementById("live-indicator").textContent = "CAMERA ACTIVE";
  document.getElementById("cam-start").disabled = true;
  document.getElementById("cam-pause").disabled = false;
  document.getElementById("cam-capture").disabled = false;
  document.getElementById("cam-stop").disabled = false;
  cameraPaused = false;

  video.onloadedmetadata = () => {
    const overlay = document.getElementById("camera-overlay");
    overlay.width = video.videoWidth;
    overlay.height = video.videoHeight;
    cameraTimer = setInterval(pollFrame, 900);
  };
}

function togglePause() {
  cameraPaused = !cameraPaused;
  document.getElementById("cam-pause").innerHTML = cameraPaused ? `${icon("play")} Resume` : `${icon("pause")} Pause`;
}

function stopCamera() {
  if (cameraTimer) clearInterval(cameraTimer);
  cameraTimer = null;
  if (cameraStream) { cameraStream.getTracks().forEach(t => t.stop()); cameraStream = null; }
  const video = document.getElementById("camera-video");
  if (video) video.srcObject = null;
  const indicator = document.getElementById("live-indicator");
  if (indicator) indicator.textContent = "CAMERA OFF";
  ["cam-start"].forEach(id => { const b = document.getElementById(id); if (b) b.disabled = false; });
  ["cam-pause", "cam-capture", "cam-stop"].forEach(id => { const b = document.getElementById(id); if (b) b.disabled = true; });
}

function grabFrameDataUrl() {
  const video = document.getElementById("camera-video");
  const tmp = document.createElement("canvas");
  tmp.width = video.videoWidth; tmp.height = video.videoHeight;
  const ctx = tmp.getContext("2d");
  ctx.drawImage(video, 0, 0, tmp.width, tmp.height);
  return tmp.toDataURL("image/jpeg", 0.75);
}

async function pollFrame() {
  if (cameraPaused || !cameraStream) return;
  const video = document.getElementById("camera-video");
  if (!video || !video.videoWidth) return;
  const dataUrl = grabFrameDataUrl();
  try {
    const result = await api("/api/inspect/frame", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image: dataUrl, capture: false, product_type: document.getElementById("cam-category").value }),
    });
    drawOverlay(result);
    document.getElementById("stat-defects").textContent = result.defect_count;
    document.getElementById("stat-severity").textContent = result.max_severity;
    document.getElementById("stat-grade").textContent = result.quality_grade;
    document.getElementById("stat-status").textContent = result.status;
  } catch (e) { /* ignore transient frame errors */ }
}

function drawOverlay(result) {
  const overlay = document.getElementById("camera-overlay");
  const video = document.getElementById("camera-video");
  if (!overlay || !video.videoWidth) return;
  overlay.width = video.videoWidth; overlay.height = video.videoHeight;
  const ctx = overlay.getContext("2d");
  ctx.clearRect(0, 0, overlay.width, overlay.height);
  const sx = overlay.width / (result.image_width || overlay.width);
  const sy = overlay.height / (result.image_height || overlay.height);
  (result.detections || []).forEach(d => {
    const [x1, y1, x2, y2] = d.bbox;
    const colorMap = { MINOR: "#29c46b", MODERATE: "#f5a524", MAJOR: "#ff5b3d", CRITICAL: "#f5455c" };
    const color = colorMap[d.severity_level] || "#29c46b";
    ctx.strokeStyle = color; ctx.lineWidth = 2;
    ctx.strokeRect(x1 * sx, y1 * sy, (x2 - x1) * sx, (y2 - y1) * sy);
    ctx.fillStyle = color;
    const label = `${d.defect.toUpperCase()} ${(d.confidence * 100).toFixed(0)}%`;
    ctx.font = "12px sans-serif";
    const tw = ctx.measureText(label).width;
    ctx.fillRect(x1 * sx, y1 * sy - 18, tw + 8, 18);
    ctx.fillStyle = "#fff";
    ctx.fillText(label, x1 * sx + 4, y1 * sy - 5);
  });
}

async function captureFrame() {
  if (!cameraStream) return;
  const btn = document.getElementById("cam-capture");
  btn.disabled = true; btn.innerHTML = `<span class="spinner"></span>`;
  const dataUrl = grabFrameDataUrl();
  try {
    const result = await api("/api/inspect/frame", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image: dataUrl, capture: true, product_type: document.getElementById("cam-category").value }),
    });
    const wrap = document.getElementById("live-result");
    wrap.innerHTML = "";
    document.getElementById("live-result").appendChild(el(`<div></div>`));
    renderCapturedResult(result);
    toast("Frame captured & added to inspection history", "success");
  } catch (e) {
    toast(e.message, "error");
  } finally {
    btn.disabled = false; btn.innerHTML = `${icon("camera")} Capture`;
  }
}

function renderCapturedResult(result) {
  const target = document.getElementById("live-result");
  const statusClass = (result.status || "pass").toLowerCase();
  target.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div class="decision-hero ${statusClass}">
        <div>
          <div class="decision-status ${statusClass}">${result.status}</div>
          <div class="muted" style="margin-top:4px;">${result.inspection_id}</div>
        </div>
        <div class="decision-meta">
          <div><div class="m-label">Grade</div><div class="m-value">${result.quality_grade}</div></div>
          <div><div class="m-label">Defects</div><div class="m-value">${result.defect_count}</div></div>
          <div><div class="m-label">Max Severity</div><div class="m-value">${result.max_severity}/100</div></div>
        </div>
      </div>
    </div>
    <div class="card" style="margin-bottom:16px;">
      <div class="image-compare"><img src="${result.annotated_path_url}"></div>
    </div>
    <div class="card">
      <div class="section-title">Defect Analysis</div>
      ${defectTable(result.detections)}
    </div>
  `;
}

// ---------------------------------------------------------------------
// RESULTS / HISTORY
// ---------------------------------------------------------------------
async function loadResultsPage(opts = {}) {
  const body = document.getElementById("results-body");
  const search = opts.search || "";
  const status = opts.status || "";
  const sort = opts.sort || "timestamp";
  const order = opts.order || "desc";

  body.innerHTML = `
    <div class="card" style="margin-bottom:16px;">
      <div class="inline-fields">
        <div><label style="font-size:11px;color:var(--text-dim);">Search</label>
          <input type="text" id="res-search" placeholder="Search ID, product, defect type\u2026" value="${escapeHtml(search)}"></div>
        <div><label style="font-size:11px;color:var(--text-dim);">Status</label>
          <select id="res-status">
            <option value="">All</option>
            <option value="PASS">PASS</option>
            <option value="REVIEW">REVIEW</option>
            <option value="REJECT">REJECT</option>
          </select>
        </div>
        <div><label style="font-size:11px;color:var(--text-dim);">Sort By</label>
          <select id="res-sort">
            <option value="timestamp">Date</option>
            <option value="max_severity">Severity</option>
            <option value="defect_count">Defect Count</option>
          </select>
        </div>
      </div>
    </div>
    <div class="card" id="res-table-wrap"><div class="skeleton" style="height:300px;"></div></div>
  `;
  document.getElementById("res-status").value = status;
  document.getElementById("res-sort").value = sort;

  const refresh = () => loadResultsPage({
    search: document.getElementById("res-search").value,
    status: document.getElementById("res-status").value,
    sort: document.getElementById("res-sort").value,
    order,
  });
  document.getElementById("res-search").addEventListener("keydown", e => { if (e.key === "Enter") refresh(); });
  document.getElementById("res-status").addEventListener("change", refresh);
  document.getElementById("res-sort").addEventListener("change", refresh);

  try {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (status) params.set("status", status);
    params.set("sort", sort); params.set("order", order);
    const data = await api("/api/inspections?" + params.toString());
    const wrap = document.getElementById("res-table-wrap");
    if (!data.inspections.length) {
      wrap.innerHTML = emptyState("No inspections match your filters.");
      return;
    }
    wrap.innerHTML = `<table class="data-table"><thead><tr>
      <th>ID</th><th>Time</th><th>Type</th><th>Product</th><th>Defects</th><th>Severity</th><th>Grade</th><th>Status</th><th></th>
    </tr></thead><tbody>
      ${data.inspections.map(r => `<tr>
        <td class="mono">${r.inspection_id}</td>
        <td>${r.timestamp}</td>
        <td>${escapeHtml(r.input_type)}</td>
        <td>${escapeHtml((r.product_type||"-").replace(/_/g," "))}</td>
        <td>${r.defect_count}</td>
        <td>${r.max_severity}/100</td>
        <td>${r.quality_grade}</td>
        <td>${statusBadge(r.status)}</td>
        <td style="white-space:nowrap;">
          <button class="btn sm ghost" data-view="${r.inspection_id}">View</button>
          <button class="btn sm ghost" onclick="window.open('/api/report/${r.inspection_id}','_blank')">PDF</button>
          <button class="btn sm danger" data-del="${r.inspection_id}">Delete</button>
        </td>
      </tr>`).join("")}
    </tbody></table>`;

    wrap.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => openInspectionModal(b.dataset.view)));
    wrap.querySelectorAll("[data-del]").forEach(b => b.addEventListener("click", async () => {
      if (!confirm("Delete this inspection record?")) return;
      await api(`/api/inspections/${b.dataset.del}`, { method: "DELETE" });
      toast("Inspection deleted", "success");
      refresh();
    }));
  } catch (e) {
    document.getElementById("res-table-wrap").innerHTML = emptyState("Failed to load: " + e.message);
  }
}

async function openInspectionModal(id) {
  const root = document.getElementById("modal-root");
  root.innerHTML = `<div class="modal-backdrop" id="modal-backdrop"><div class="modal">Loading\u2026</div></div>`;
  document.getElementById("modal-backdrop").addEventListener("click", e => { if (e.target.id === "modal-backdrop") root.innerHTML = ""; });
  try {
    const r = await api(`/api/inspections/${id}`);
    const statusClass = (r.status || "pass").toLowerCase();
    document.querySelector(".modal").innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
        <h2 style="margin:0;font-size:17px;">${r.inspection_id}</h2>
        <button class="btn sm ghost" onclick="document.getElementById('modal-root').innerHTML=''">Close</button>
      </div>
      <div class="decision-hero ${statusClass}" style="margin-bottom:14px;">
        <div><div class="decision-status ${statusClass}">${r.status}</div>
        <div class="muted">${r.timestamp}</div></div>
        <div class="decision-meta">
          <div><div class="m-label">Grade</div><div class="m-value">${r.quality_grade}</div></div>
          <div><div class="m-label">Defects</div><div class="m-value">${r.defect_count}</div></div>
          <div><div class="m-label">Severity</div><div class="m-value">${r.max_severity}/100</div></div>
        </div>
      </div>
      <div class="grid grid-2" style="margin-bottom:14px;">
        ${r.image_url ? `<div class="image-compare"><img src="${r.image_url}"></div>` : ""}
        ${r.annotated_url ? `<div class="image-compare"><img src="${r.annotated_url}"></div>` : ""}
      </div>
      ${defectTable((r.result_json || {}).detections)}
      <div style="margin-top:14px;">
        <button class="btn primary" onclick="window.open('/api/report/${r.inspection_id}','_blank')">${icon('fileText')} Generate Report</button>
      </div>
    `;
  } catch (e) {
    document.querySelector(".modal").innerHTML = emptyState("Could not load inspection: " + e.message);
  }
}

// ---------------------------------------------------------------------
// ANALYTICS
// ---------------------------------------------------------------------
async function loadAnalyticsPage() {
  const body = document.getElementById("analytics-body");
  try {
    const stats = await api("/api/dashboard");
    body.innerHTML = `
      <div class="grid grid-4" style="margin-bottom:18px;">
        ${kpiCard("Total Inspections", stats.total_inspections, icon("barChart", 20))}
        ${kpiCard("Pass Rate", stats.pass_rate + "%", icon("checkCircle", 20))}
        ${kpiCard("Avg Severity", stats.average_severity, icon("trendingDown", 20))}
        ${kpiCard("Rejected", stats.rejected, icon("xCircle", 20))}
      </div>
      <div class="grid grid-2" style="margin-bottom:18px;">
        <div class="card chart-card"><div class="section-title">Defect Frequency by Type</div><canvas id="a-chart1" data-h="240"></canvas></div>
        <div class="card chart-card"><div class="section-title">Pass / Reject Trend</div><canvas id="a-chart2" data-h="240"></canvas></div>
      </div>
      <div class="grid grid-2">
        <div class="card chart-card"><div class="section-title">Severity Distribution</div><canvas id="a-chart3" data-h="220"></canvas></div>
        <div class="card chart-card"><div class="section-title">Quality Grade Breakdown</div><canvas id="a-chart4" data-h="220"></canvas></div>
      </div>
    `;
    const byType = stats.defects_by_type || {};
    drawBarChart(document.getElementById("a-chart1"), Object.keys(byType), Object.values(byType), { colors: COLORS.palette });
    const timeline = stats.timeline || [];
    drawLineChart(document.getElementById("a-chart2"), timeline.map(t => t.date), [
      { name: "Total", values: timeline.map(t => t.count), color: COLORS.accent },
      { name: "Rejects", values: timeline.map(t => t.rejects), color: COLORS.red },
    ]);
    const sevDist = stats.severity_distribution || {};
    drawBarChart(document.getElementById("a-chart3"), Object.keys(sevDist), Object.values(sevDist), { colors: [COLORS.green, COLORS.amber, "#ff8a3d", COLORS.red] });
    const grades = stats.grades || {};
    drawBarChart(document.getElementById("a-chart4"), Object.keys(grades), Object.values(grades), { colors: [COLORS.green, COLORS.accent, COLORS.amber, COLORS.red] });
  } catch (e) {
    body.innerHTML = emptyState("Could not load analytics: " + e.message);
  }
}

// ---------------------------------------------------------------------
// DATASET
// ---------------------------------------------------------------------
async function loadDatasetPage() {
  const body = document.getElementById("dataset-body");
  try {
    const info = await api("/api/dataset");
    if (!info.exists) {
      body.innerHTML = emptyState('No dataset generated yet. Click "Generate Demo Dataset" above to create it.');
      return;
    }
    body.innerHTML = `
      <div class="pill-tag" style="margin-bottom:16px; display:inline-block;">${info.dataset_type.replace(/_/g," ")}</div>
      <div class="grid grid-4" style="margin-bottom:18px;">
        ${kpiCard("Total Products", info.total_samples, icon("package", 20))}
        ${kpiCard("Training Samples", info.split_counts.train, icon("activity", 20))}
        ${kpiCard("Validation Samples", info.split_counts.val, icon("target", 20))}
        ${kpiCard("Defect Classes", info.classes.length, icon("tag", 20))}
      </div>
      <div class="grid grid-2" style="margin-bottom:18px;">
        <div class="card chart-card"><div class="section-title">Samples per Class</div><canvas id="d-chart1" data-h="230"></canvas></div>
        <div class="card chart-card"><div class="section-title">Samples per Product Category</div><canvas id="d-chart2" data-h="230"></canvas></div>
      </div>
      <div class="card">
        <div class="section-title">Preview Samples <span class="muted">filter by class</span></div>
        <select id="preview-filter" style="max-width:220px; margin-bottom:14px;">
          <option value="">All classes</option>
          ${info.classes.map(c => `<option value="${c}">${c}</option>`).join("")}
        </select>
        <div class="thumb-grid" id="preview-grid"><div class="skeleton" style="height:110px;"></div></div>
      </div>
    `;
    drawBarChart(document.getElementById("d-chart1"), Object.keys(info.class_counts), Object.values(info.class_counts), { colors: COLORS.palette });
    drawBarChart(document.getElementById("d-chart2"), Object.keys(info.category_counts).map(c=>c.replace(/_/g," ")), Object.values(info.category_counts), { color: COLORS.accent });

    const loadPreview = async () => {
      const label = document.getElementById("preview-filter").value;
      const grid = document.getElementById("preview-grid");
      grid.innerHTML = `<div class="skeleton" style="height:110px;"></div>`;
      const data = await api("/api/dataset/preview" + (label ? `?label=${label}&limit=16` : "?limit=16"));
      if (!data.samples.length) { grid.innerHTML = emptyState("No samples for this filter."); return; }
      grid.innerHTML = data.samples.map(s => `
        <div class="thumb"><img src="${s.url}" loading="lazy">
          <div class="thumb-label"><span>${escapeHtml(s.category.replace(/_/g," "))}</span><span>${escapeHtml(s.labels.join(", ") || "normal")}</span></div>
        </div>`).join("");
    };
    document.getElementById("preview-filter").addEventListener("change", loadPreview);
    loadPreview();
  } catch (e) {
    body.innerHTML = emptyState("Failed to load dataset info: " + e.message);
  }
}

document.getElementById("btn-generate-dataset").addEventListener("click", async () => {
  const btn = document.getElementById("btn-generate-dataset");
  btn.disabled = true; btn.innerHTML = `<span class="spinner"></span> Generating\u2026`;
  try {
    const r = await api("/api/dataset/generate", { method: "POST" });
    toast(`Generated ${r.generated} samples`, "success");
    loadDatasetPage();
  } catch (e) {
    toast(e.message, "error");
  } finally {
    btn.disabled = false; btn.innerHTML = `${icon("refresh")} Generate Demo Dataset`;
  }
});

// ---------------------------------------------------------------------
// MODEL
// ---------------------------------------------------------------------
async function loadModelPage() {
  const body = document.getElementById("model-body");
  try {
    const info = await api("/api/model");
    const m = info.metrics || {};
    const hasMetrics = m.accuracy !== undefined;
    body.innerHTML = `
      <div class="grid grid-2" style="margin-bottom:18px;">
        <div class="card">
          <div class="section-title">${info.name} <span class="muted">${info.version}</span></div>
          <div class="pill-tag" style="margin-bottom:14px;">${info.prototype_label}</div>
          <table class="data-table">
            <tr><td class="muted">Architecture</td><td>${escapeHtml(info.architecture)}</td></tr>
            <tr><td class="muted">Classes</td><td>${info.num_classes}</td></tr>
            <tr><td class="muted">Input Size</td><td>${info.input_size} \u00d7 ${info.input_size}</td></tr>
            <tr><td class="muted">Inference Device</td><td>${info.device}</td></tr>
            <tr><td class="muted">Confidence Threshold</td><td>${info.confidence_threshold}</td></tr>
            <tr><td class="muted">IoU Threshold</td><td>${info.iou_threshold}</td></tr>
            <tr><td class="muted">Model Loaded</td><td>${info.loaded ? "Yes" : "No \u2014 train the model first"}</td></tr>
          </table>
        </div>
        <div class="card">
          <div class="section-title">Evaluation Metrics</div>
          ${hasMetrics ? `
          <div class="grid grid-2">
            ${kpiCard("Accuracy", (m.accuracy*100).toFixed(1)+"%", icon("target", 20))}
            ${kpiCard("Precision (macro)", (m.precision_macro*100).toFixed(1)+"%", icon("crosshair", 20))}
            ${kpiCard("Recall (macro)", (m.recall_macro*100).toFixed(1)+"%", icon("trendingUp", 20))}
            ${kpiCard("F1 (macro)", (m.f1_macro*100).toFixed(1)+"%", icon("sliders", 20))}
          </div>
          <p class="muted" style="font-size:12px; margin-top:14px;">${escapeHtml(m.note || "")}</p>
          <p class="muted" style="font-size:11.5px;">Trained: ${m.trained_at} \u00b7 Train samples: ${m.n_train_samples} \u00b7 Test samples: ${m.n_test_samples}</p>
          ` : emptyState("Demo Model \u2014 metrics pending evaluation. Click Retrain Model to train and evaluate.")}
        </div>
      </div>
      <div class="card">
        <div class="section-title">Defect Classes</div>
        <div class="tag-row">${info.classes.map(c => `<span class="pill-tag">${c}</span>`).join("")}</div>
      </div>
    `;
  } catch (e) {
    body.innerHTML = emptyState("Failed to load model info: " + e.message);
  }
}

document.getElementById("btn-train-model").addEventListener("click", async () => {
  const btn = document.getElementById("btn-train-model");
  btn.disabled = true; btn.innerHTML = `<span class="spinner"></span> Training\u2026`;
  try {
    const r = await api("/api/model/train", { method: "POST" });
    toast("Model retrained successfully", "success");
    loadModelPage();
  } catch (e) {
    toast(e.message, "error");
  } finally {
    btn.disabled = false; btn.innerHTML = `${icon("zap")} Retrain Model`;
  }
});

// ---------------------------------------------------------------------
// SETTINGS
// ---------------------------------------------------------------------
async function loadSettingsPage() {
  const body = document.getElementById("settings-body");
  try {
    const cfg = await api("/api/settings");
    body.innerHTML = `
      <div class="card" style="max-width:640px;">
        <div class="settings-group">
          <h3>Detection</h3>
          <div class="field">
            <label>Confidence Threshold <span class="range-value" id="conf-val">${cfg.model.confidence_threshold}</span></label>
            <input type="range" min="0.1" max="0.9" step="0.05" id="set-confidence" value="${cfg.model.confidence_threshold}">
          </div>
        </div>
        <div class="settings-group">
          <h3>Severity Thresholds</h3>
          <div class="inline-fields">
            <div class="field"><label>Minor &lt;</label><input type="number" id="sev-minor" value="${cfg.severity.minor_threshold}"></div>
            <div class="field"><label>Moderate &lt;</label><input type="number" id="sev-moderate" value="${cfg.severity.moderate_threshold}"></div>
            <div class="field"><label>Major &lt;</label><input type="number" id="sev-major" value="${cfg.severity.major_threshold}"></div>
          </div>
        </div>
        <div class="settings-group">
          <h3>Quality Grading</h3>
          <div class="inline-fields">
            <div class="field"><label>Grade A max</label><input type="number" id="grade-a" value="${cfg.grading.grade_a_max}"></div>
            <div class="field"><label>Grade B max</label><input type="number" id="grade-b" value="${cfg.grading.grade_b_max}"></div>
            <div class="field"><label>Grade C max</label><input type="number" id="grade-c" value="${cfg.grading.grade_c_max}"></div>
          </div>
        </div>
        <div class="settings-group">
          <h3>Camera</h3>
          <div class="inline-fields">
            <div class="field"><label>Target FPS</label><input type="number" id="cam-fps" value="${cfg.camera.target_fps}"></div>
            <div class="field"><label>Inference Width</label><input type="number" id="cam-width" value="${cfg.camera.inference_width}"></div>
          </div>
        </div>
        <button class="btn primary" id="save-settings">Save Settings</button>
      </div>
    `;
    const slider = document.getElementById("set-confidence");
    slider.addEventListener("input", () => document.getElementById("conf-val").textContent = slider.value);

    document.getElementById("save-settings").addEventListener("click", async () => {
      const payload = {
        confidence_threshold: parseFloat(document.getElementById("set-confidence").value),
        severity: {
          minor_threshold: parseFloat(document.getElementById("sev-minor").value),
          moderate_threshold: parseFloat(document.getElementById("sev-moderate").value),
          major_threshold: parseFloat(document.getElementById("sev-major").value),
        },
        grading: {
          grade_a_max: parseFloat(document.getElementById("grade-a").value),
          grade_b_max: parseFloat(document.getElementById("grade-b").value),
          grade_c_max: parseFloat(document.getElementById("grade-c").value),
        },
      };
      try {
        await api("/api/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
        toast("Settings saved", "success");
      } catch (e) {
        toast(e.message, "error");
      }
    });
  } catch (e) {
    body.innerHTML = emptyState("Failed to load settings: " + e.message);
  }
}

// ---------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------
checkHealth();
setInterval(checkHealth, 15000);
navigate(window.location.hash ? window.location.hash.slice(1) : "dashboard");
