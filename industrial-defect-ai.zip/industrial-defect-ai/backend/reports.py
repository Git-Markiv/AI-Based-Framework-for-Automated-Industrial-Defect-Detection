"""
PDF Report Generator
======================
Builds a professional-looking, single-page-plus inspection report using
reportlab. Content is populated entirely from the inspection's own stored
result_json - nothing here is fabricated.
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                 TableStyle, Image as RLImage, HRFlowable)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER

STATUS_COLOR = {
    "PASS": colors.HexColor("#1a9d54"),
    "REVIEW": colors.HexColor("#d98c00"),
    "REJECT": colors.HexColor("#d9342b"),
}


def generate_report(inspection, output_path):
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                             topMargin=18 * mm, bottomMargin=15 * mm,
                             leftMargin=16 * mm, rightMargin=16 * mm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("TitleX", parent=styles["Title"], fontSize=18,
                                  textColor=colors.HexColor("#1c2431"))
    h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=12,
                         textColor=colors.HexColor("#1c2431"), spaceBefore=10, spaceAfter=6)
    normal = styles["Normal"]
    small = ParagraphStyle("Small", parent=styles["Normal"], fontSize=8.5,
                            textColor=colors.HexColor("#666666"))

    story = []
    story.append(Paragraph("DEFECTAI — Industrial Quality Inspection Report", title_style))
    story.append(Paragraph("Explainable AI-Based Automated Defect Detection, "
                            "Severity Assessment &amp; Quality Grading", small))
    story.append(Spacer(1, 6))
    story.append(HRFlowable(width="100%", color=colors.HexColor("#dddddd")))
    story.append(Spacer(1, 10))

    meta_table = Table([
        ["Inspection ID", inspection.get("inspection_id", "-"),
         "Date / Time", inspection.get("timestamp", "-")],
        ["Input Type", inspection.get("input_type", "-").title(),
         "Product Category", (inspection.get("product_type") or "-").replace("_", " ").title()],
    ], colWidths=[80, 160, 90, 150])
    meta_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("TEXTCOLOR", (0, 0), (0, -1), colors.grey),
        ("TEXTCOLOR", (2, 0), (2, -1), colors.grey),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 8))

    status = inspection.get("status", "PASS")
    status_color = STATUS_COLOR.get(status, colors.grey)
    decision_table = Table([[
        Paragraph(f"<b>{status}</b>", ParagraphStyle("st", fontSize=20, textColor=colors.white,
                                                       alignment=TA_CENTER)),
        Paragraph(f"Grade<br/><b>{inspection.get('quality_grade','-')}</b>",
                  ParagraphStyle("gr", fontSize=11, alignment=TA_CENTER)),
        Paragraph(f"Defects<br/><b>{inspection.get('defect_count',0)}</b>",
                  ParagraphStyle("df", fontSize=11, alignment=TA_CENTER)),
        Paragraph(f"Max Severity<br/><b>{inspection.get('max_severity',0)}/100</b>",
                  ParagraphStyle("sv", fontSize=11, alignment=TA_CENTER)),
    ]], colWidths=[120, 100, 100, 130])
    decision_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, 0), status_color),
        ("BACKGROUND", (1, 0), (-1, 0), colors.HexColor("#f4f5f7")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
    ]))
    story.append(decision_table)
    story.append(Spacer(1, 14))

    images_row = []
    for label, path in [("Original", inspection.get("image_path")),
                         ("Detection", inspection.get("annotated_path")),
                         ("Heatmap", inspection.get("heatmap_path"))]:
        if path and os.path.isfile(path):
            img = RLImage(path, width=155, height=155)
            images_row.append([img, Paragraph(label, ParagraphStyle("lbl", alignment=TA_CENTER, fontSize=9))])
    if images_row:
        story.append(Paragraph("Visual Evidence", h2))
        img_table = Table([[c[0] for c in images_row], [c[1] for c in images_row]])
        img_table.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
        story.append(img_table)
        story.append(Spacer(1, 10))

    defects = inspection.get("result_json", {}).get("detections", [])
    if defects:
        story.append(Paragraph("Defect Analysis", h2))
        rows = [["Type", "Confidence", "Severity", "Area %", "Location (bbox)"]]
        for d in defects:
            rows.append([
                d.get("defect", "-").title(),
                f"{d.get('confidence',0)*100:.1f}%",
                f"{d.get('severity',0):.0f}/100 ({d.get('severity_level','-')})",
                f"{d.get('area_percentage',0):.1f}%",
                str(d.get("bbox", "-")),
            ])
        t = Table(rows, colWidths=[70, 70, 130, 55, 145])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1c2431")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f8fa")]),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)
        story.append(Spacer(1, 10))

    story.append(Paragraph("Severity Calculation (transparent formula)", h2))
    story.append(Paragraph(
        "Severity Score = Area Impact × 0.35 + Defect Type Risk × 0.25 + "
        "Location Risk × 0.20 + Defect Count × 0.10 + Model Confidence × 0.10, "
        "normalised to 0–100.", normal))
    story.append(Spacer(1, 10))

    story.append(Paragraph("AI Explanation", h2))
    explanation = inspection.get("result_json", {}).get("explanation_text", "")
    for line in explanation.split("\n"):
        story.append(Paragraph(line.replace("\u2022", "&bull;"), normal))
    story.append(Spacer(1, 14))

    story.append(HRFlowable(width="100%", color=colors.HexColor("#dddddd")))
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "Dataset: Synthetic Demonstration Dataset. Model: Prototype / Demonstration Model "
        "(classical computer-vision region proposal + RandomForest ensemble classifier). "
        "This report is generated by an academic/demonstration prototype and is not validated "
        "for real industrial deployment.", small))

    doc.build(story)
    return output_path
