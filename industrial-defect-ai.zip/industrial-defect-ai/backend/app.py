"""
DefectAI Backend
==================
Flask application exposing the REST API used by the frontend. Wires
together: preprocessing -> detection -> severity -> grading ->
explainability -> persistence (SQLite) -> PDF reporting.
"""
import os
import io
import time
import uuid
import base64
import shutil
import traceback

import cv2
import numpy as np
from flask import Flask, request, jsonify, send_from_directory, send_file, abort
from werkzeug.utils import secure_filename

from backend.config_loader import load_config
from backend.database import Database
from backend.reports import generate_report
from ai.preprocessing import Preprocessor
from ai.detector import Detector
from ai.severity import SeverityEngine
from ai.grading import GradingEngine
from ai import explainability
from dataset.generator import generate_dataset, dataset_exists, PRODUCT_CATEGORIES, ALL_CLASSES
from ai.training import train_model, model_exists

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ALLOWED_IMAGE_EXT = {"jpg", "jpeg", "png", "webp"}
ALLOWED_VIDEO_EXT = {"mp4", "avi", "mov", "mkv", "webm"}
MAX_CONTENT_LENGTH = 200 * 1024 * 1024  # 200MB safety cap


def _allowed(filename, allowed_set):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in allowed_set


def _safe_name(prefix, ext):
    return f"{prefix}_{uuid.uuid4().hex[:10]}.{ext}"


class Pipeline:
    """Bundles the loaded config + AI components used across requests."""

    def __init__(self):
        self.cfg = load_config()
        self.paths = self.cfg["paths"]
        for key in ("data_dir", "models_dir", "uploads_dir", "outputs_dir", "reports_dir"):
            os.makedirs(os.path.join(ROOT, self.paths[key]), exist_ok=True)
        os.makedirs(os.path.dirname(os.path.join(ROOT, self.paths["database_path"])), exist_ok=True)

        self.preprocessor = Preprocessor(self.cfg["preprocessing"])
        self.detector = Detector(
            model_path=os.path.join(ROOT, self.paths["models_dir"], "defectnet_rf.joblib"),
            confidence_threshold=self.cfg["model"]["confidence_threshold"],
            iou_threshold=self.cfg["model"]["iou_threshold"],
        )
        self.severity_engine = SeverityEngine(self.cfg["severity"])
        self.grading_engine = GradingEngine(self.cfg["grading"])
        self.db = Database(os.path.join(ROOT, self.paths["database_path"]))

    def reload_detector(self):
        self.detector = Detector(
            model_path=os.path.join(ROOT, self.paths["models_dir"], "defectnet_rf.joblib"),
            confidence_threshold=self.cfg["model"]["confidence_threshold"],
            iou_threshold=self.cfg["model"]["iou_threshold"],
        )

    def data_dir(self):
        return os.path.join(ROOT, self.paths["data_dir"])

    def models_dir(self):
        return os.path.join(ROOT, self.paths["models_dir"])

    def uploads_dir(self):
        return os.path.join(ROOT, self.paths["uploads_dir"])

    def outputs_dir(self):
        return os.path.join(ROOT, self.paths["outputs_dir"])

    def reports_dir(self):
        return os.path.join(ROOT, self.paths["reports_dir"])


PIPE = None  # lazily created singleton, see create_app()


def run_inspection_on_image(img_bgr, input_type="image", product_type=None,
                             persist=True, inspection_id=None, fast=False):
    """Runs the full pipeline on a single BGR image and (optionally) persists
    the result + artifacts. Returns the JSON-serialisable result dict."""
    pre_img, scale = PIPE.preprocessor.run(img_bgr, resize=True, fast=fast)
    h, w = pre_img.shape[:2]

    detections = PIPE.detector.detect(pre_img)
    scored, max_severity = PIPE.severity_engine.score_all(detections, w, h)
    grade_info = PIPE.grading_engine.grade(max_severity, len(scored))

    product_name = (product_type or "industrial_component").replace("_", " ").title()
    explanation_text = explainability.build_explanation_text(scored, max_severity, grade_info, product_name)

    result = {
        "inspection_id": inspection_id or f"INS-{uuid.uuid4().hex[:10].upper()}",
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "input_type": input_type,
        "product_type": product_type or "industrial_component",
        "image_width": w,
        "image_height": h,
        "detections": scored,
        "defect_count": len(scored),
        "defect_types": sorted(list({d["defect"] for d in scored})),
        "max_severity": max_severity,
        "quality_grade": grade_info["grade"],
        "status": grade_info["status"],
        "grade_reason": grade_info["reason"],
        "average_confidence": round(float(np.mean([d["confidence"] for d in scored])) * 100, 1) if scored else 0.0,
        "explanation_text": explanation_text,
        "device": PIPE.detector.device,
        "model_loaded": PIPE.detector.loaded,
        "dataset_type": "SYNTHETIC_DEMONSTRATION_DATASET",
    }

    image_path = annotated_path = heatmap_path = None
    if persist:
        insp_id = result["inspection_id"]
        image_path = os.path.join(PIPE.uploads_dir(), f"{insp_id}_original.jpg")
        cv2.imwrite(image_path, pre_img)

        detection_img = explainability.draw_detections(pre_img, scored)
        annotated_path = os.path.join(PIPE.outputs_dir(), f"{insp_id}_detection.jpg")
        cv2.imwrite(annotated_path, detection_img)

        heatmap_img = explainability.generate_heatmap(pre_img)
        heatmap_path = os.path.join(PIPE.outputs_dir(), f"{insp_id}_heatmap.jpg")
        cv2.imwrite(heatmap_path, heatmap_img)

        result["image_path"] = image_path
        result["annotated_path"] = annotated_path
        result["heatmap_path"] = heatmap_path

        PIPE.db.insert_inspection({
            "inspection_id": insp_id,
            "timestamp": result["timestamp"],
            "input_type": input_type,
            "product_type": result["product_type"],
            "defect_count": result["defect_count"],
            "defect_types": result["defect_types"],
            "max_severity": result["max_severity"],
            "quality_grade": result["quality_grade"],
            "status": result["status"],
            "confidence": result["average_confidence"],
            "image_path": image_path,
            "annotated_path": annotated_path,
            "heatmap_path": heatmap_path,
            "result_json": result,
        })

    return result, {"image_path": image_path, "annotated_path": annotated_path, "heatmap_path": heatmap_path}


def _url_for_file(path):
    if not path:
        return None
    rel = os.path.relpath(path, ROOT).replace(os.sep, "/")
    return f"/files/{rel}"


def _result_with_urls(result):
    out = dict(result)
    for key in ("image_path", "annotated_path", "heatmap_path"):
        if key in out:
            out[key + "_url"] = _url_for_file(out[key])
    return out


def create_app():
    global PIPE
    app = Flask(__name__, static_folder=None)
    app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
    PIPE = Pipeline()

    frontend_dir = os.path.join(ROOT, "backend", "static")

    # ------------------------------------------------------------------
    # Static / frontend
    # ------------------------------------------------------------------
    @app.route("/")
    def index():
        return send_from_directory(frontend_dir, "index.html")

    @app.route("/static/<path:path>")
    def static_files(path):
        full = os.path.join(frontend_dir, path)
        if os.path.isfile(full):
            return send_from_directory(frontend_dir, path)
        abort(404)

    @app.route("/files/<path:path>")
    def serve_generated_files(path):
        full = os.path.join(ROOT, path)
        directory = os.path.dirname(full)
        filename = os.path.basename(full)
        if not os.path.isfile(full):
            abort(404)
        return send_from_directory(directory, filename)

    # ------------------------------------------------------------------
    # Health / model / dataset
    # ------------------------------------------------------------------
    @app.route("/api/health")
    def health():
        return jsonify({
            "status": "ok",
            "model_loaded": PIPE.detector.loaded,
            "dataset_ready": dataset_exists(PIPE.data_dir()),
            "device": PIPE.detector.device,
        })

    @app.route("/api/model")
    def model_info():
        info = PIPE.detector.model_info()
        metrics_path = os.path.join(PIPE.models_dir(), "metrics.json")
        metrics = None
        if os.path.isfile(metrics_path):
            import json
            with open(metrics_path) as f:
                metrics = json.load(f)
        return jsonify({
            "name": PIPE.cfg["model"]["name"],
            "version": PIPE.cfg["model"]["version"],
            "architecture": PIPE.cfg["model"]["architecture"],
            "classes": ALL_CLASSES,
            "num_classes": len(ALL_CLASSES),
            "input_size": PIPE.cfg["model"]["input_size"],
            "device": PIPE.detector.device,
            "loaded": info["loaded"],
            "confidence_threshold": PIPE.detector.confidence_threshold,
            "iou_threshold": PIPE.detector.iou_threshold,
            "metrics": metrics or {"note": "Demo Model — metrics pending evaluation"},
            "is_prototype": True,
            "prototype_label": "Prototype / Demonstration Model",
        })

    @app.route("/api/dataset")
    def dataset_info():
        meta_path = os.path.join(PIPE.data_dir(), "metadata", "dataset.json")
        if not os.path.isfile(meta_path):
            return jsonify({"exists": False})
        import json
        with open(meta_path) as f:
            meta = json.load(f)
        records = meta["records"]
        split_counts = {"train": 0, "val": 0, "test": 0}
        class_counts = {c: 0 for c in ALL_CLASSES}
        category_counts = {c: 0 for c in PRODUCT_CATEGORIES}
        for r in records:
            split_counts[r["split"]] = split_counts.get(r["split"], 0) + 1
            category_counts[r["category"]] = category_counts.get(r["category"], 0) + 1
            if r["is_normal"]:
                class_counts["normal"] += 1
            for d in r["defects"]:
                class_counts[d["label"]] = class_counts.get(d["label"], 0) + 1
        return jsonify({
            "exists": True,
            "dataset_type": meta.get("dataset_type", "SYNTHETIC_DEMONSTRATION_DATASET"),
            "total_samples": meta["total_samples"],
            "split_counts": split_counts,
            "class_counts": class_counts,
            "category_counts": category_counts,
            "classes": ALL_CLASSES,
            "product_categories": PRODUCT_CATEGORIES,
        })

    @app.route("/api/dataset/preview")
    def dataset_preview():
        import json
        meta_path = os.path.join(PIPE.data_dir(), "metadata", "dataset.json")
        if not os.path.isfile(meta_path):
            return jsonify({"samples": []})
        with open(meta_path) as f:
            meta = json.load(f)
        records = meta["records"]
        label_filter = request.args.get("label")
        limit = int(request.args.get("limit", 12))
        out = []
        for r in records:
            labels = [d["label"] for d in r["defects"]] or (["normal"] if r["is_normal"] else [])
            if label_filter and label_filter not in labels:
                continue
            out.append({
                "id": r["id"],
                "category": r["category"],
                "labels": labels,
                "is_normal": r["is_normal"],
                "url": f"/files/data/{r['path']}",
            })
            if len(out) >= limit:
                break
        return jsonify({"samples": out})

    @app.route("/api/dataset/generate", methods=["POST"])
    def dataset_generate():
        try:
            total = int(request.json.get("total_samples", PIPE.cfg["dataset"]["total_samples"])) if request.is_json else PIPE.cfg["dataset"]["total_samples"]
            records = generate_dataset(PIPE.data_dir(), total_samples=total)
            return jsonify({"success": True, "generated": len(records)})
        except Exception as e:
            traceback.print_exc()
            return jsonify({"success": False, "error": str(e)}), 500

    @app.route("/api/model/train", methods=["POST"])
    def model_train():
        try:
            metrics = train_model(data_root=PIPE.data_dir(), models_dir=PIPE.models_dir())
            PIPE.reload_detector()
            return jsonify({"success": True, "metrics": metrics})
        except Exception as e:
            traceback.print_exc()
            return jsonify({"success": False, "error": str(e)}), 500

    # ------------------------------------------------------------------
    # Image inspection
    # ------------------------------------------------------------------
    @app.route("/api/inspect/image", methods=["POST"])
    def inspect_image():
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400
        file = request.files["file"]
        if file.filename == "" or not _allowed(file.filename, ALLOWED_IMAGE_EXT):
            return jsonify({"error": "Unsupported or missing image file (jpg/jpeg/png/webp only)"}), 400

        product_type = request.form.get("product_type", "industrial_component")
        try:
            data = np.frombuffer(file.read(), np.uint8)
            img = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if img is None:
                return jsonify({"error": "Could not decode image. The file may be corrupted."}), 400
            result, _ = run_inspection_on_image(img, input_type="image", product_type=product_type)
            return jsonify(_result_with_urls(result))
        except Exception as e:
            traceback.print_exc()
            return jsonify({"error": f"Inspection failed: {e}"}), 500

    @app.route("/api/inspect/demo", methods=["POST"])
    def inspect_demo():
        """Try Demo Inspection: pick a random sample from the generated dataset."""
        import json
        import random
        meta_path = os.path.join(PIPE.data_dir(), "metadata", "dataset.json")
        if not os.path.isfile(meta_path):
            return jsonify({"error": "Dataset not generated yet."}), 400
        with open(meta_path) as f:
            meta = json.load(f)
        records = [r for r in meta["records"] if not r["is_normal"]]
        rec = random.choice(records) if records else random.choice(meta["records"])
        img_path = os.path.join(PIPE.data_dir(), rec["path"])
        img = cv2.imread(img_path)
        if img is None:
            return jsonify({"error": "Could not load demo sample."}), 500
        result, _ = run_inspection_on_image(img, input_type="image", product_type=rec["category"])
        return jsonify(_result_with_urls(result))

    # ------------------------------------------------------------------
    # Live camera - single frame inspection (polled from the browser)
    # ------------------------------------------------------------------
    @app.route("/api/inspect/frame", methods=["POST"])
    def inspect_frame():
        payload = request.get_json(silent=True) or {}
        b64 = payload.get("image")
        capture = bool(payload.get("capture", False))
        product_type = payload.get("product_type", "industrial_component")
        if not b64:
            return jsonify({"error": "Missing 'image' (base64) field"}), 400
        try:
            if "," in b64:
                b64 = b64.split(",", 1)[1]
            raw = base64.b64decode(b64)
            data = np.frombuffer(raw, np.uint8)
            img = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if img is None:
                return jsonify({"error": "Could not decode camera frame"}), 400
        except Exception as e:
            return jsonify({"error": f"Bad frame payload: {e}"}), 400

        try:
            if capture:
                result, _ = run_inspection_on_image(img, input_type="camera",
                                                      product_type=product_type,
                                                      persist=True, fast=False)
                return jsonify(_result_with_urls(result))
            else:
                result, _ = run_inspection_on_image(img, input_type="camera",
                                                      product_type=product_type,
                                                      persist=False, fast=True)
                return jsonify(_result_with_urls(result))
        except Exception as e:
            traceback.print_exc()
            return jsonify({"error": f"Live inference failed: {e}"}), 500

    # ------------------------------------------------------------------
    # Video inspection (synchronous, frame-sampled)
    # ------------------------------------------------------------------
    @app.route("/api/inspect/video", methods=["POST"])
    def inspect_video():
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400
        file = request.files["file"]
        if file.filename == "" or not _allowed(file.filename, ALLOWED_VIDEO_EXT):
            return jsonify({"error": "Unsupported or missing video file (mp4/avi/mov/mkv/webm only)"}), 400

        product_type = request.form.get("product_type", "industrial_component")
        insp_id = f"INS-{uuid.uuid4().hex[:10].upper()}"
        tmp_path = os.path.join(PIPE.uploads_dir(), f"{insp_id}_input.mp4")
        file.save(tmp_path)

        try:
            cap = cv2.VideoCapture(tmp_path)
            if not cap.isOpened():
                return jsonify({"error": "Could not open the uploaded video. It may be corrupted or an "
                                          "unsupported codec."}), 400

            fps = cap.get(cv2.CAP_PROP_FPS) or 24
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

            # Cap total inference calls for a responsive CPU-only demo.
            max_inferences = 60
            frame_skip = max(1, total_frames // max_inferences) if total_frames else 5

            out_path = os.path.join(PIPE.outputs_dir(), f"{insp_id}_annotated.mp4")
            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(out_path, fourcc, fps, (w, h)) if w and h else None

            frame_idx = 0
            processed = 0
            all_detections = []
            defect_type_counts = {}
            max_severity = 0.0
            last_detections = []

            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                if frame_idx % frame_skip == 0:
                    pre_img, scale = PIPE.preprocessor.run(frame, resize=True, fast=True)
                    dets = PIPE.detector.detect(pre_img)
                    scored, sev = PIPE.severity_engine.score_all(dets, pre_img.shape[1], pre_img.shape[0])
                    if scored:
                        # scale boxes back up for drawing on the full-res frame
                        sx, sy = w / pre_img.shape[1], h / pre_img.shape[0]
                        for d in scored:
                            x1, y1, x2, y2 = d["bbox"]
                            d["bbox"] = [int(x1 * sx), int(y1 * sy), int(x2 * sx), int(y2 * sy)]
                    last_detections = scored
                    max_severity = max(max_severity, sev)
                    for d in scored:
                        defect_type_counts[d["defect"]] = defect_type_counts.get(d["defect"], 0) + 1
                    all_detections.extend(scored)
                    processed += 1

                if writer is not None:
                    annotated = explainability.draw_detections(frame, last_detections)
                    writer.write(annotated)
                frame_idx += 1

            cap.release()
            if writer is not None:
                writer.release()

            grade_info = PIPE.grading_engine.grade(max_severity, len(defect_type_counts))
            top_detections = sorted(all_detections, key=lambda d: d["severity"], reverse=True)[:10]
            explanation = explainability.build_explanation_text(
                top_detections, max_severity, grade_info,
                (product_type or "industrial_component").replace("_", " ").title())

            result = {
                "inspection_id": insp_id,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "input_type": "video",
                "product_type": product_type,
                "frames_total": total_frames,
                "frames_processed": processed,
                "frame_skip": frame_skip,
                "defects_found": len(all_detections),
                "defect_type_counts": defect_type_counts,
                "defect_types": sorted(list(defect_type_counts.keys())),
                "defect_count": len(defect_type_counts),
                "max_severity": round(max_severity, 1),
                "quality_grade": grade_info["grade"],
                "status": grade_info["status"],
                "grade_reason": grade_info["reason"],
                "explanation_text": explanation,
                "detections": top_detections,
                "annotated_video_path": out_path if writer is not None else None,
                "dataset_type": "SYNTHETIC_DEMONSTRATION_DATASET",
            }

            PIPE.db.insert_inspection({
                "inspection_id": insp_id,
                "timestamp": result["timestamp"],
                "input_type": "video",
                "product_type": product_type,
                "defect_count": result["defect_count"],
                "defect_types": result["defect_types"],
                "max_severity": result["max_severity"],
                "quality_grade": result["quality_grade"],
                "status": result["status"],
                "confidence": round(float(np.mean([d["confidence"] for d in all_detections])) * 100, 1) if all_detections else 0.0,
                "image_path": None,
                "annotated_path": out_path if writer is not None else None,
                "heatmap_path": None,
                "result_json": result,
            })

            out = dict(result)
            out["annotated_video_url"] = _url_for_file(out["annotated_video_path"])
            return jsonify(out)
        except Exception as e:
            traceback.print_exc()
            return jsonify({"error": f"Video inspection failed: {e}"}), 500
        finally:
            try:
                os.remove(tmp_path)
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Inspection history
    # ------------------------------------------------------------------
    @app.route("/api/inspections")
    def list_inspections():
        search = request.args.get("search")
        status = request.args.get("status")
        sort = request.args.get("sort", "timestamp")
        order = request.args.get("order", "desc")
        rows = PIPE.db.list_inspections(search=search, status=status, sort=sort, order=order)
        for r in rows:
            r["image_url"] = _url_for_file(r.get("image_path"))
            r["annotated_url"] = _url_for_file(r.get("annotated_path"))
        return jsonify({"inspections": rows, "count": len(rows)})

    @app.route("/api/inspections/<inspection_id>")
    def get_inspection(inspection_id):
        row = PIPE.db.get_inspection(inspection_id)
        if not row:
            return jsonify({"error": "Not found"}), 404
        row["image_url"] = _url_for_file(row.get("image_path"))
        row["annotated_url"] = _url_for_file(row.get("annotated_path"))
        row["heatmap_url"] = _url_for_file(row.get("heatmap_path"))
        return jsonify(row)

    @app.route("/api/inspections/<inspection_id>", methods=["DELETE"])
    def delete_inspection(inspection_id):
        PIPE.db.delete_inspection(inspection_id)
        return jsonify({"success": True})

    @app.route("/api/inspections", methods=["DELETE"])
    def clear_inspections():
        PIPE.db.clear_all()
        return jsonify({"success": True})

    # ------------------------------------------------------------------
    # Dashboard / analytics
    # ------------------------------------------------------------------
    @app.route("/api/dashboard")
    def dashboard():
        return jsonify(PIPE.db.dashboard_stats())

    # ------------------------------------------------------------------
    # PDF report
    # ------------------------------------------------------------------
    @app.route("/api/report/<inspection_id>", methods=["GET", "POST"])
    def report(inspection_id):
        row = PIPE.db.get_inspection(inspection_id)
        if not row:
            return jsonify({"error": "Not found"}), 404
        out_path = os.path.join(PIPE.reports_dir(), f"{inspection_id}_report.pdf")
        try:
            generate_report(row, out_path)
            return send_file(out_path, as_attachment=True,
                              download_name=f"{inspection_id}_report.pdf")
        except Exception as e:
            traceback.print_exc()
            return jsonify({"error": f"Report generation failed: {e}"}), 500

    # ------------------------------------------------------------------
    # Settings (read/update runtime thresholds)
    # ------------------------------------------------------------------
    @app.route("/api/settings", methods=["GET"])
    def get_settings():
        return jsonify(PIPE.cfg)

    @app.route("/api/settings", methods=["POST"])
    def update_settings():
        payload = request.get_json(silent=True) or {}
        try:
            if "confidence_threshold" in payload:
                PIPE.detector.confidence_threshold = float(payload["confidence_threshold"])
            if "severity" in payload:
                PIPE.severity_engine = SeverityEngine({**PIPE.cfg["severity"], **payload["severity"]})
            if "grading" in payload:
                PIPE.grading_engine = GradingEngine({**PIPE.cfg["grading"], **payload["grading"]})
            return jsonify({"success": True})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 400

    @app.errorhandler(413)
    def too_large(e):
        return jsonify({"error": "File too large."}), 413

    @app.errorhandler(500)
    def internal_error(e):
        return jsonify({"error": "Internal server error. Please try again."}), 500

    return app
