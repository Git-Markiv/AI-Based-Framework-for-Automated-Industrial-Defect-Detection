#!/usr/bin/env python3
"""
DEFECTAI — One-command launcher
=================================
    python run.py

This script:
  1. Verifies required Python dependencies are installed.
  2. Creates all required directories.
  3. Generates the synthetic demonstration dataset if it doesn't exist yet.
  4. Trains the DefectNet model if a trained model isn't saved yet.
  5. Starts the Flask web application.
  6. Opens your default browser to the running app.

No dataset to find, no model to train manually, no complicated setup.
"""
import os
import sys
import time
import threading
import webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

REQUIRED_PACKAGES = [
    ("flask", "Flask"),
    ("cv2", "opencv-python"),
    ("numpy", "numpy"),
    ("sklearn", "scikit-learn"),
    ("joblib", "joblib"),
    ("reportlab", "reportlab"),
    ("yaml", "PyYAML"),
]


def banner(text):
    print("\n" + "=" * 64)
    print(text)
    print("=" * 64)


def check_dependencies():
    banner("STEP 1/5 — Checking Python dependencies")
    missing = []
    for module_name, pip_name in REQUIRED_PACKAGES:
        try:
            __import__(module_name)
            print(f"  [OK] {pip_name}")
        except ImportError:
            print(f"  [MISSING] {pip_name}")
            missing.append(pip_name)
    if missing:
        print("\nMissing packages detected. Install them with:\n")
        print(f"    pip install {' '.join(missing)} --break-system-packages\n")
        print("(or simply: pip install -r requirements.txt)")
        sys.exit(1)
    print("All dependencies satisfied.")


def create_directories():
    banner("STEP 2/5 — Preparing project directories")
    from backend.config_loader import load_config
    cfg = load_config()
    for key in ("data_dir", "models_dir", "uploads_dir", "outputs_dir", "reports_dir"):
        path = os.path.join(ROOT, cfg["paths"][key])
        os.makedirs(path, exist_ok=True)
        print(f"  [OK] {path}")
    os.makedirs(os.path.dirname(os.path.join(ROOT, cfg["paths"]["database_path"])), exist_ok=True)
    return cfg


def ensure_dataset(cfg):
    banner("STEP 3/5 — Checking synthetic demonstration dataset")
    from dataset.generator import generate_dataset, dataset_exists
    data_dir = os.path.join(ROOT, cfg["paths"]["data_dir"])
    if dataset_exists(data_dir):
        print("  Dataset already present — skipping generation.")
        print("  (Use the Dataset page in the UI to regenerate it at any time.)")
        return
    print("  No dataset found. Generating SYNTHETIC DEMONSTRATION DATASET...")
    total = cfg["dataset"]["total_samples"]

    def progress(done, total):
        bar_len = 30
        filled = int(bar_len * done / total)
        bar = "#" * filled + "-" * (bar_len - filled)
        sys.stdout.write(f"\r  [{bar}] {done}/{total}")
        sys.stdout.flush()

    generate_dataset(data_dir, total_samples=total, progress_cb=progress)
    print(f"\n  Generated {total} synthetic samples across "
          f"{len(cfg['dataset']['product_categories'])} product categories.")


def ensure_model(cfg):
    banner("STEP 4/5 — Checking trained model")
    from ai.training import train_model, model_exists
    models_dir = os.path.join(ROOT, cfg["paths"]["models_dir"])
    if model_exists(models_dir):
        print("  Trained model already present — skipping training.")
        print("  (Use the Model page in the UI to retrain at any time.)")
        return
    print("  No trained model found. Training DefectNet "
          "(classical-CV features + RandomForest ensemble)...")
    data_dir = os.path.join(ROOT, cfg["paths"]["data_dir"])
    metrics = train_model(data_root=data_dir, models_dir=models_dir)
    print(f"  Training complete. Accuracy={metrics['accuracy']*100:.1f}%  "
          f"F1(macro)={metrics['f1_macro']*100:.1f}%")
    print("  (Metrics computed on the synthetic dataset's held-out test split.)")


def start_server(cfg):
    banner("STEP 5/5 — Starting DefectAI web application")
    from backend.app import create_app
    app = create_app()
    host = cfg["server"]["host"]
    port = cfg["server"]["port"]
    url = f"http://{host}:{port}"

    print(f"\n  DefectAI is running at:  {url}\n")
    print("  Press CTRL+C to stop the server.\n")

    def open_browser():
        time.sleep(1.3)
        try:
            webbrowser.open(url)
        except Exception:
            pass

    threading.Thread(target=open_browser, daemon=True).start()
    app.run(host=host, port=port, debug=cfg["server"].get("debug", False), use_reloader=False, threaded=True)


def main():
    print(r"""
  ____        __          _   _    _____
 |  _ \  ___ / _| ___  ___| |_/ \  |_   _|
 | | | |/ _ \ |_ / _ \/ __| __| _ \   | |
 | |_| |  __/  _|  __/ (__| |_/ ___ \  | |
 |____/ \___|_|  \___|\___|\__/_/   \_\ |_|

 Explainable AI-Based Industrial Defect Detection,
 Severity Assessment & Product Quality Grading Platform
""")
    check_dependencies()
    cfg = create_directories()
    ensure_dataset(cfg)
    ensure_model(cfg)
    start_server(cfg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nDefectAI stopped. Goodbye!")
        sys.exit(0)
