"""
Synthetic Demonstration Dataset Generator
==========================================
Generates a labeled, realistic-looking dataset of industrial product surfaces
with procedurally rendered defects (scratch, dent, hole, crack, corrosion,
discoloration) plus normal / defect-free samples.

IMPORTANT (Honesty requirement): this is a SYNTHETIC DEMONSTRATION DATASET.
It is not a real industrial photography dataset. It exists so the whole
application is runnable end-to-end out of the box. It is clearly labeled as
such throughout the application.

Each sample gets:
  - a base "product" texture depending on its product category
  - zero or more procedurally rendered defects with bounding boxes
  - a metadata record: defect labels, bboxes, severity label, quality grade
"""
import os
import json
import random
import math
import numpy as np
import cv2

RNG_SEED = 42

DEFECT_CLASSES = ["scratch", "dent", "hole", "crack", "corrosion", "discoloration"]
ALL_CLASSES = ["normal"] + DEFECT_CLASSES

PRODUCT_CATEGORIES = [
    "metal_panel", "automotive_part", "pipe", "machine_component",
    "electronic_housing", "bottle", "sheet_metal", "bearing",
    "gear", "industrial_component",
]

# Base tint per product category (BGR) so the synthetic surfaces look varied.
CATEGORY_BASE_COLOR = {
    "metal_panel":        (150, 150, 150),
    "automotive_part":    (110, 110, 120),
    "pipe":               (120, 135, 140),
    "machine_component":  (100, 100, 105),
    "electronic_housing": (60, 60, 65),
    "bottle":             (170, 190, 200),
    "sheet_metal":        (160, 160, 165),
    "bearing":            (90, 90, 95),
    "gear":               (95, 100, 100),
    "industrial_component": (130, 130, 135),
}


def _seeded_rng(idx):
    return np.random.RandomState(RNG_SEED + idx)


def _make_base_surface(size, category, rng):
    """Create a procedurally textured metallic/plastic base surface."""
    h, w = size
    base_color = np.array(CATEGORY_BASE_COLOR.get(category, (140, 140, 140)), dtype=np.float32)

    # Base flat color
    img = np.ones((h, w, 3), dtype=np.float32) * base_color

    # Brushed-metal style directional noise
    noise = rng.normal(0, 9, (h, w)).astype(np.float32)
    noise = cv2.GaussianBlur(noise, (0, 0), sigmaX=1.2, sigmaY=0.15)
    for c in range(3):
        img[:, :, c] += noise

    # Low frequency lighting gradient (simulated studio light)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx, cy = rng.uniform(0.2, 0.8) * w, rng.uniform(0.1, 0.5) * h
    dist = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    dist = dist / dist.max()
    light = (1.0 - 0.35 * dist)
    for c in range(3):
        img[:, :, c] *= light

    # Subtle vignette
    vign = 1.0 - 0.25 * (dist ** 2)
    for c in range(3):
        img[:, :, c] *= vign

    # Fine grain texture (speckle)
    speckle = rng.normal(0, 4, (h, w)).astype(np.float32)
    for c in range(3):
        img[:, :, c] += speckle

    img = np.clip(img, 0, 255).astype(np.uint8)

    # Occasional machined circular / rectangular guide lines for realism
    if rng.rand() < 0.5:
        n_lines = rng.randint(1, 4)
        for _ in range(n_lines):
            y = rng.randint(0, h)
            shade = rng.randint(-10, 10)
            cv2.line(img, (0, y), (w, y), tuple(int(np.clip(c + shade, 0, 255)) for c in base_color), 1)
    return img


def _random_thin_curve_mask(h, w, rng, branch=False):
    """Generate a mask of a thin irregular curve (used for scratch/crack)."""
    mask = np.zeros((h, w), dtype=np.uint8)
    x, y = rng.randint(int(w * 0.1), int(w * 0.9)), rng.randint(int(h * 0.1), int(h * 0.9))
    angle = rng.uniform(0, 2 * math.pi)
    length = rng.randint(int(min(h, w) * 0.25), int(min(h, w) * 0.6))
    pts = [(x, y)]
    step = max(2, length // 40)
    cur_angle = angle
    for _ in range(step):
        cur_angle += rng.uniform(-0.35, 0.35)
        seg_len = length / step
        x = int(np.clip(x + seg_len * math.cos(cur_angle), 0, w - 1))
        y = int(np.clip(y + seg_len * math.sin(cur_angle), 0, h - 1))
        pts.append((x, y))
    thickness = rng.randint(1, 3)
    for i in range(len(pts) - 1):
        cv2.line(mask, pts[i], pts[i + 1], 255, thickness)

    if branch and rng.rand() < 0.8:
        # Add branching sub-cracks
        n_branches = rng.randint(1, 3)
        for _ in range(n_branches):
            bi = rng.randint(1, len(pts) - 1)
            bx, by = pts[bi]
            bangle = cur_angle + rng.choice([-1, 1]) * rng.uniform(0.4, 1.2)
            blen = rng.randint(int(length * 0.2), int(length * 0.5))
            bx2 = int(np.clip(bx + blen * math.cos(bangle), 0, w - 1))
            by2 = int(np.clip(by + blen * math.sin(bangle), 0, h - 1))
            cv2.line(mask, (bx, by), (bx2, by2), 255, max(1, thickness - 1))

    mask = cv2.GaussianBlur(mask, (3, 3), 0)
    return mask, pts


def render_scratch(img, rng):
    h, w = img.shape[:2]
    n = rng.randint(1, 3)
    boxes = []
    for _ in range(n):
        mask, pts = _random_thin_curve_mask(h, w, rng, branch=False)
        dark = rng.uniform(0.45, 0.75)
        highlight_offset = rng.randint(1, 2)
        m = mask.astype(np.float32) / 255.0
        for c in range(3):
            img[:, :, c] = img[:, :, c] * (1 - m * (1 - dark))
        ys, xs = np.where(mask > 10)
        if len(xs) == 0:
            continue
        x1, x2, y1, y2 = xs.min(), xs.max(), ys.min(), ys.max()
        pad = 4
        boxes.append([max(0, int(x1 - pad)), max(0, int(y1 - pad)),
                      min(w - 1, int(x2 + pad)), min(h - 1, int(y2 + pad))])
    return img, boxes


def render_crack(img, rng):
    h, w = img.shape[:2]
    mask, pts = _random_thin_curve_mask(h, w, rng, branch=True)
    m = mask.astype(np.float32) / 255.0
    dark = 0.25
    for c in range(3):
        img[:, :, c] = img[:, :, c] * (1 - m * (1 - dark))
    ys, xs = np.where(mask > 10)
    if len(xs) == 0:
        return img, []
    x1, x2, y1, y2 = xs.min(), xs.max(), ys.min(), ys.max()
    pad = 5
    box = [max(0, int(x1 - pad)), max(0, int(y1 - pad)),
           min(w - 1, int(x2 + pad)), min(h - 1, int(y2 + pad))]
    return img, [box]


def render_dent(img, rng):
    h, w = img.shape[:2]
    cx, cy = rng.randint(int(w * 0.2), int(w * 0.8)), rng.randint(int(h * 0.2), int(h * 0.8))
    rx, ry = rng.randint(15, 45), rng.randint(12, 35)
    yy, xx = np.mgrid[0:h, 0:w]
    ellipse = ((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2
    mask = np.clip(1 - ellipse, 0, 1) ** 1.5

    # Shading: darker on one side, highlight on the opposite side (depression look)
    shade = np.zeros_like(mask)
    light_dx, light_dy = rng.uniform(-1, 1), rng.uniform(-1, 1)
    grad = (xx - cx) * light_dx + (yy - cy) * light_dy
    grad = grad / (np.abs(grad).max() + 1e-6)
    shade = mask * grad

    for c in range(3):
        img[:, :, c] = np.clip(img[:, :, c].astype(np.float32) - shade * 55 - mask * 18, 0, 255)

    x1, x2 = max(0, cx - rx - 4), min(w - 1, cx + rx + 4)
    y1, y2 = max(0, cy - ry - 4), min(h - 1, cy + ry + 4)
    return img.astype(np.uint8), [[int(x1), int(y1), int(x2), int(y2)]]


def render_hole(img, rng):
    h, w = img.shape[:2]
    cx, cy = rng.randint(int(w * 0.25), int(w * 0.75)), rng.randint(int(h * 0.25), int(h * 0.75))
    r = rng.randint(10, 28)
    overlay = img.copy()
    cv2.circle(overlay, (cx, cy), r, (10, 10, 10), -1)
    cv2.circle(overlay, (cx, cy), r, (0, 0, 0), 1)
    # inner shadow ring for depth
    cv2.circle(overlay, (cx, cy), max(1, r - 4), (25, 25, 25), 2)
    overlay = cv2.GaussianBlur(overlay, (3, 3), 0)
    mask = np.zeros((h, w), dtype=np.uint8)
    cv2.circle(mask, (cx, cy), r + 2, 255, -1)
    m = (mask.astype(np.float32) / 255.0)[..., None]
    img = (img.astype(np.float32) * (1 - m) + overlay.astype(np.float32) * m).astype(np.uint8)
    x1, x2 = max(0, cx - r - 3), min(w - 1, cx + r + 3)
    y1, y2 = max(0, cy - r - 3), min(h - 1, cy + r + 3)
    return img, [[int(x1), int(y1), int(x2), int(y2)]]


def render_corrosion(img, rng):
    h, w = img.shape[:2]
    cx, cy = rng.randint(int(w * 0.2), int(w * 0.8)), rng.randint(int(h * 0.2), int(h * 0.8))
    rw, rh = rng.randint(25, 60), rng.randint(20, 50)

    # Irregular blob via thresholded blurred noise
    noise = rng.normal(0, 1, (h, w)).astype(np.float32)
    noise = cv2.GaussianBlur(noise, (0, 0), sigmaX=8)
    yy, xx = np.mgrid[0:h, 0:w]
    ellipse = ((xx - cx) / rw) ** 2 + ((yy - cy) / rh) ** 2
    blob = (ellipse < 1).astype(np.float32) + noise * 0.3
    blob = np.clip(blob, 0, 1)
    blob = cv2.GaussianBlur(blob, (5, 5), 0)

    rust_color = np.array([15, 70, 140], dtype=np.float32)  # BGR rust/orange
    for c in range(3):
        img[:, :, c] = img[:, :, c].astype(np.float32) * (1 - blob) + rust_color[c] * blob
    # add darker pitting texture on top
    pit_noise = (rng.rand(h, w) > 0.985).astype(np.float32) * blob
    pit_noise = cv2.GaussianBlur(pit_noise, (3, 3), 0)
    for c in range(3):
        img[:, :, c] = img[:, :, c] - pit_noise * 40

    img = np.clip(img, 0, 255).astype(np.uint8)
    ys, xs = np.where(blob > 0.25)
    if len(xs) == 0:
        return img, []
    x1, x2, y1, y2 = xs.min(), xs.max(), ys.min(), ys.max()
    return img, [[int(x1), int(y1), int(x2), int(y2)]]


def render_discoloration(img, rng):
    h, w = img.shape[:2]
    cx, cy = rng.randint(int(w * 0.2), int(w * 0.8)), rng.randint(int(h * 0.2), int(h * 0.8))
    rw, rh = rng.randint(35, 80), rng.randint(30, 70)
    yy, xx = np.mgrid[0:h, 0:w]
    ellipse = ((xx - cx) / rw) ** 2 + ((yy - cy) / rh) ** 2
    mask = np.clip(1 - ellipse, 0, 1) ** 0.8
    mask = cv2.GaussianBlur(mask.astype(np.float32), (7, 7), 0)

    tint = np.array([rng.uniform(-40, 40), rng.uniform(-40, 40), rng.uniform(-40, 40)], dtype=np.float32)
    for c in range(3):
        img[:, :, c] = np.clip(img[:, :, c].astype(np.float32) + mask * tint[c], 0, 255)
    img = img.astype(np.uint8)
    ys, xs = np.where(mask > 0.15)
    if len(xs) == 0:
        return img, []
    x1, x2, y1, y2 = xs.min(), xs.max(), ys.min(), ys.max()
    return img, [[int(x1), int(y1), int(x2), int(y2)]]


DEFECT_RENDERERS = {
    "scratch": render_scratch,
    "dent": render_dent,
    "hole": render_hole,
    "crack": render_crack,
    "corrosion": render_corrosion,
    "discoloration": render_discoloration,
}


def _bbox_area_pct(box, h, w):
    x1, y1, x2, y2 = box
    return 100.0 * max(0, (x2 - x1)) * max(0, (y2 - y1)) / (h * w)


def generate_sample(idx, size=(320, 320)):
    rng = _seeded_rng(idx)
    category = PRODUCT_CATEGORIES[idx % len(PRODUCT_CATEGORIES)]
    img = _make_base_surface(size, category, rng)
    h, w = size

    # ~28% of samples are normal / defect free
    is_normal = rng.rand() < 0.28
    defects = []
    if not is_normal:
        n_defects = rng.choice([1, 1, 1, 2], p=[0.55, 0.2, 0.15, 0.10])
        chosen = rng.choice(DEFECT_CLASSES, size=n_defects, replace=False)
        for defect_type in chosen:
            img, boxes = DEFECT_RENDERERS[str(defect_type)](img, rng)
            for b in boxes:
                defects.append({
                    "label": str(defect_type),
                    "bbox": b,
                    "area_pct": round(_bbox_area_pct(b, h, w), 2),
                })

    record = {
        "id": f"sample_{idx:04d}",
        "category": category,
        "is_normal": is_normal or len(defects) == 0,
        "defects": defects,
        "width": w,
        "height": h,
    }
    return img, record


def generate_dataset(output_root, total_samples=220, splits=(0.7, 0.15, 0.15), progress_cb=None):
    """Generate the full synthetic dataset with train/val/test split + metadata."""
    os.makedirs(output_root, exist_ok=True)
    for split in ("train", "val", "test"):
        os.makedirs(os.path.join(output_root, split), exist_ok=True)
    meta_dir = os.path.join(output_root, "metadata")
    os.makedirs(meta_dir, exist_ok=True)
    ann_dir = os.path.join(output_root, "annotations")
    os.makedirs(ann_dir, exist_ok=True)

    n_train = int(total_samples * splits[0])
    n_val = int(total_samples * splits[1])
    n_test = total_samples - n_train - n_val

    split_plan = (["train"] * n_train) + (["val"] * n_val) + (["test"] * n_test)
    random.Random(RNG_SEED).shuffle(split_plan)

    all_records = []
    for i in range(total_samples):
        img, record = generate_sample(i)
        split = split_plan[i]
        record["split"] = split
        fname = f"{record['id']}.jpg"
        fpath = os.path.join(output_root, split, fname)
        cv2.imwrite(fpath, img)
        record["path"] = os.path.join(split, fname)
        all_records.append(record)
        if progress_cb:
            progress_cb(i + 1, total_samples)

    with open(os.path.join(meta_dir, "dataset.json"), "w") as f:
        json.dump({
            "dataset_type": "SYNTHETIC_DEMONSTRATION_DATASET",
            "total_samples": total_samples,
            "classes": ALL_CLASSES,
            "product_categories": PRODUCT_CATEGORIES,
            "records": all_records,
        }, f, indent=2)

    return all_records


def dataset_exists(output_root):
    meta_path = os.path.join(output_root, "metadata", "dataset.json")
    return os.path.isfile(meta_path)


if __name__ == "__main__":
    recs = generate_dataset("data", total_samples=220)
    print(f"Generated {len(recs)} samples.")
