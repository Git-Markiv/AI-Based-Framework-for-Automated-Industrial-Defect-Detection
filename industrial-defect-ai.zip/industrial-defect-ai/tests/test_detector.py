import os
import unittest
import numpy as np
import cv2

from ai.detector import Detector, _iou, _nms, propose_regions

MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "models", "defectnet_rf.joblib")


class TestIouAndNms(unittest.TestCase):
    def test_iou_identical_boxes(self):
        box = [10, 10, 50, 50]
        self.assertAlmostEqual(_iou(box, box), 1.0)

    def test_iou_no_overlap(self):
        self.assertEqual(_iou([0, 0, 10, 10], [100, 100, 120, 120]), 0.0)

    def test_nms_removes_overlaps(self):
        dets = [
            {"bbox": [10, 10, 50, 50], "confidence": 0.9},
            {"bbox": [12, 12, 52, 52], "confidence": 0.8},
            {"bbox": [200, 200, 240, 240], "confidence": 0.7},
        ]
        kept = _nms(dets, iou_thresh=0.3)
        self.assertEqual(len(kept), 2)
        self.assertEqual(kept[0]["confidence"], 0.9)


class TestRegionProposal(unittest.TestCase):
    def test_uniform_image_yields_few_or_no_regions(self):
        flat = np.ones((320, 320, 3), dtype=np.uint8) * 140
        boxes = propose_regions(flat)
        self.assertLessEqual(len(boxes), 2)

    def test_bright_blob_is_detected(self):
        img = np.ones((320, 320, 3), dtype=np.uint8) * 140
        cv2.circle(img, (160, 160), 30, (10, 10, 10), -1)
        boxes = propose_regions(img)
        self.assertGreaterEqual(len(boxes), 1)


@unittest.skipUnless(os.path.isfile(MODEL_PATH), "Trained model not present; run training first.")
class TestDetectorWithModel(unittest.TestCase):
    def setUp(self):
        self.detector = Detector(model_path=MODEL_PATH, confidence_threshold=0.3)

    def test_model_loaded(self):
        self.assertTrue(self.detector.loaded)

    def test_detect_returns_list(self):
        img = (np.random.rand(320, 320, 3) * 255).astype(np.uint8)
        dets = self.detector.detect(img)
        self.assertIsInstance(dets, list)

    def test_detection_schema(self):
        img = np.ones((320, 320, 3), dtype=np.uint8) * 140
        cv2.circle(img, (160, 160), 20, (5, 5, 5), -1)
        dets = self.detector.detect(img)
        for d in dets:
            self.assertIn("defect", d)
            self.assertIn("confidence", d)
            self.assertIn("bbox", d)
            self.assertIn("area_percentage", d)
            self.assertEqual(len(d["bbox"]), 4)


if __name__ == "__main__":
    unittest.main()
