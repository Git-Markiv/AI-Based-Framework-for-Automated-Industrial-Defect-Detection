import unittest
import numpy as np

from ai.preprocessing import Preprocessor


class TestPreprocessing(unittest.TestCase):
    def setUp(self):
        self.img = (np.random.rand(400, 600, 3) * 255).astype(np.uint8)
        self.pre = Preprocessor({"resize_width": 320, "resize_height": 320,
                                  "denoise": True, "clahe": True})

    def test_resize_keeps_aspect(self):
        resized, scale = self.pre.resize(self.img)
        h, w = resized.shape[:2]
        self.assertLessEqual(w, 320)
        self.assertLessEqual(h, 320)
        self.assertGreater(scale, 0)

    def test_run_pipeline_shape(self):
        out, scale = self.pre.run(self.img)
        self.assertEqual(out.shape[2], 3)
        self.assertLessEqual(out.shape[0], 320)
        self.assertLessEqual(out.shape[1], 320)

    def test_fast_mode_skips_denoise(self):
        out_fast, _ = self.pre.run(self.img, fast=True)
        out_full, _ = self.pre.run(self.img, fast=False)
        self.assertEqual(out_fast.shape, out_full.shape)

    def test_clahe_does_not_crash_on_grayscale_like_image(self):
        flat = np.ones((100, 100, 3), dtype=np.uint8) * 128
        out = self.pre.apply_clahe(flat)
        self.assertEqual(out.shape, flat.shape)


if __name__ == "__main__":
    unittest.main()
