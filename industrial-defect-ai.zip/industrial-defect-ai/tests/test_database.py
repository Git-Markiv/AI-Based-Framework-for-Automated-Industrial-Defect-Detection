import os
import shutil
import tempfile
import unittest

from backend.database import Database


class TestDatabase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db = Database(os.path.join(self.tmpdir, "test.db"))

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _sample_record(self, **overrides):
        rec = {
            "input_type": "image", "product_type": "bottle", "defect_count": 1,
            "defect_types": ["scratch"], "max_severity": 42.0, "quality_grade": "B",
            "status": "PASS", "confidence": 88.0, "image_path": "/tmp/x.jpg",
            "annotated_path": "/tmp/y.jpg", "heatmap_path": "/tmp/z.jpg",
            "result_json": {"detections": []},
        }
        rec.update(overrides)
        return rec

    def test_insert_and_get(self):
        insp_id = self.db.insert_inspection(self._sample_record())
        row = self.db.get_inspection(insp_id)
        self.assertIsNotNone(row)
        self.assertEqual(row["quality_grade"], "B")
        self.assertEqual(row["defect_types"], ["scratch"])

    def test_list_and_filter_by_status(self):
        self.db.insert_inspection(self._sample_record(status="PASS"))
        self.db.insert_inspection(self._sample_record(status="REJECT"))
        rejects = self.db.list_inspections(status="REJECT")
        self.assertEqual(len(rejects), 1)
        self.assertEqual(rejects[0]["status"], "REJECT")

    def test_search(self):
        self.db.insert_inspection(self._sample_record(product_type="bearing"))
        self.db.insert_inspection(self._sample_record(product_type="pipe"))
        results = self.db.list_inspections(search="bearing")
        self.assertEqual(len(results), 1)

    def test_delete(self):
        insp_id = self.db.insert_inspection(self._sample_record())
        self.db.delete_inspection(insp_id)
        self.assertIsNone(self.db.get_inspection(insp_id))

    def test_dashboard_stats(self):
        self.db.insert_inspection(self._sample_record(status="PASS", max_severity=10))
        self.db.insert_inspection(self._sample_record(status="REJECT", max_severity=90))
        stats = self.db.dashboard_stats()
        self.assertEqual(stats["total_inspections"], 2)
        self.assertEqual(stats["rejected"], 1)
        self.assertEqual(stats["pass_rate"], 50.0)


if __name__ == "__main__":
    unittest.main()
