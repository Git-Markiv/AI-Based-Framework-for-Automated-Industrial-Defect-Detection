import os
import shutil
import tempfile
import unittest

from dataset.generator import generate_dataset, generate_sample, dataset_exists, ALL_CLASSES


class TestDatasetGenerator(unittest.TestCase):
    def test_generate_sample_returns_valid_record(self):
        img, record = generate_sample(0)
        self.assertEqual(img.shape[2], 3)
        self.assertIn("id", record)
        self.assertIn("category", record)
        self.assertIsInstance(record["defects"], list)
        for d in record["defects"]:
            self.assertIn(d["label"], ALL_CLASSES)
            self.assertEqual(len(d["bbox"]), 4)

    def test_generate_dataset_creates_expected_structure(self):
        tmp = tempfile.mkdtemp()
        try:
            records = generate_dataset(tmp, total_samples=12, splits=(0.5, 0.25, 0.25))
            self.assertEqual(len(records), 12)
            self.assertTrue(dataset_exists(tmp))
            for split in ("train", "val", "test"):
                self.assertTrue(os.path.isdir(os.path.join(tmp, split)))
            meta_path = os.path.join(tmp, "metadata", "dataset.json")
            self.assertTrue(os.path.isfile(meta_path))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_dataset_not_exists_for_empty_dir(self):
        tmp = tempfile.mkdtemp()
        try:
            self.assertFalse(dataset_exists(tmp))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
