import unittest

from ai.severity import SeverityEngine
from ai.grading import GradingEngine


class TestSeverityEngine(unittest.TestCase):
    def setUp(self):
        self.engine = SeverityEngine({
            "weights": {"area_impact": 0.35, "defect_type_risk": 0.25,
                        "location_risk": 0.20, "defect_count": 0.10, "model_confidence": 0.10},
            "minor_threshold": 30, "moderate_threshold": 60, "major_threshold": 80,
        })

    def test_no_detections_zero_severity(self):
        scored, max_sev = self.engine.score_all([], 640, 640)
        self.assertEqual(scored, [])
        self.assertEqual(max_sev, 0.0)

    def test_severity_in_range(self):
        det = {"defect": "crack", "confidence": 0.95, "area_percentage": 20.0,
                "bbox": [280, 280, 360, 360]}
        result = self.engine.score_single(det, 640, 640, defect_count=1)
        self.assertGreaterEqual(result["score"], 0)
        self.assertLessEqual(result["score"], 100)

    def test_crack_scores_higher_than_discoloration(self):
        base = {"confidence": 0.8, "area_percentage": 10.0, "bbox": [280, 280, 360, 360]}
        crack = self.engine.score_single({**base, "defect": "crack"}, 640, 640, 1)
        disc = self.engine.score_single({**base, "defect": "discoloration"}, 640, 640, 1)
        self.assertGreater(crack["score"], disc["score"])

    def test_more_area_increases_severity(self):
        base = {"defect": "scratch", "confidence": 0.8, "bbox": [280, 280, 360, 360]}
        small = self.engine.score_single({**base, "area_percentage": 2.0}, 640, 640, 1)
        large = self.engine.score_single({**base, "area_percentage": 20.0}, 640, 640, 1)
        self.assertGreater(large["score"], small["score"])

    def test_level_thresholds(self):
        self.assertEqual(self.engine.level_for_score(0), "NONE")
        self.assertEqual(self.engine.level_for_score(15), "MINOR")
        self.assertEqual(self.engine.level_for_score(45), "MODERATE")
        self.assertEqual(self.engine.level_for_score(85), "CRITICAL")


class TestGradingEngine(unittest.TestCase):
    def setUp(self):
        self.engine = GradingEngine({"grade_a_max": 20, "grade_b_max": 45, "grade_c_max": 75})

    def test_no_defects_is_grade_a_pass(self):
        result = self.engine.grade(0, 0)
        self.assertEqual(result["grade"], "A")
        self.assertEqual(result["status"], "PASS")

    def test_high_severity_is_reject(self):
        result = self.engine.grade(90, 2)
        self.assertEqual(result["grade"], "REJECT")
        self.assertEqual(result["status"], "REJECT")

    def test_moderate_severity_is_review(self):
        result = self.engine.grade(60, 1)
        self.assertEqual(result["grade"], "C")
        self.assertEqual(result["status"], "REVIEW")

    def test_boundary_values(self):
        self.assertEqual(self.engine.grade(20, 1)["grade"], "A")
        self.assertEqual(self.engine.grade(45, 1)["grade"], "B")
        self.assertEqual(self.engine.grade(75, 1)["grade"], "C")
        self.assertEqual(self.engine.grade(76, 1)["grade"], "REJECT")


if __name__ == "__main__":
    unittest.main()
