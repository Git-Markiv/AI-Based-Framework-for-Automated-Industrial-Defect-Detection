import io
import os
import shutil
import tempfile
import unittest

import cv2
import numpy as np

from backend.app import create_app
import backend.app as app_module
from backend.database import Database


def _fake_image_bytes():
    img = np.ones((200, 200, 3), dtype=np.uint8) * 150
    cv2.circle(img, (100, 100), 20, (10, 10, 10), -1)
    ok, buf = cv2.imencode(".jpg", img)
    return buf.tobytes()


class TestAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.testing = True
        cls.client = cls.app.test_client()

        # IMPORTANT: redirect all persistence to a temp sandbox so running the
        # test suite never writes into the real project's database/uploads/
        # outputs (which would pollute actual inspection history).
        cls._tmpdir = tempfile.mkdtemp(prefix="defectai_test_")
        pipe = app_module.PIPE
        pipe.db = Database(os.path.join(cls._tmpdir, "test.db"))
        for sub in ("uploads", "outputs", "reports"):
            os.makedirs(os.path.join(cls._tmpdir, sub), exist_ok=True)
        pipe.uploads_dir = lambda: os.path.join(cls._tmpdir, "uploads")
        pipe.outputs_dir = lambda: os.path.join(cls._tmpdir, "outputs")
        pipe.reports_dir = lambda: os.path.join(cls._tmpdir, "reports")

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls._tmpdir, ignore_errors=True)

    def test_health(self):
        resp = self.client.get("/api/health")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("status", resp.get_json())

    def test_model_info(self):
        resp = self.client.get("/api/model")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("classes", data)
        self.assertIn("architecture", data)

    def test_dataset_info(self):
        resp = self.client.get("/api/dataset")
        self.assertEqual(resp.status_code, 200)

    def test_dashboard(self):
        resp = self.client.get("/api/dashboard")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("total_inspections", data)

    def test_inspect_image_success(self):
        data = {"file": (io.BytesIO(_fake_image_bytes()), "test.jpg"),
                "product_type": "bottle"}
        resp = self.client.post("/api/inspect/image", data=data, content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 200)
        result = resp.get_json()
        self.assertIn("status", result)
        self.assertIn("quality_grade", result)
        self.assertIn("inspection_id", result)

    def test_inspect_image_rejects_bad_extension(self):
        data = {"file": (io.BytesIO(b"not an image"), "test.exe")}
        resp = self.client.post("/api/inspect/image", data=data, content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 400)

    def test_inspect_image_no_file(self):
        resp = self.client.post("/api/inspect/image", data={}, content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 400)

    def test_inspect_image_corrupted_file(self):
        data = {"file": (io.BytesIO(b"garbage-not-an-actual-image"), "test.jpg")}
        resp = self.client.post("/api/inspect/image", data=data, content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 400)

    def test_inspect_video_rejects_bad_extension(self):
        data = {"file": (io.BytesIO(b"not a video"), "test.txt")}
        resp = self.client.post("/api/inspect/video", data=data, content_type="multipart/form-data")
        self.assertEqual(resp.status_code, 400)

    def test_inspections_list_and_get(self):
        data = {"file": (io.BytesIO(_fake_image_bytes()), "test2.jpg")}
        create_resp = self.client.post("/api/inspect/image", data=data, content_type="multipart/form-data")
        insp_id = create_resp.get_json()["inspection_id"]

        list_resp = self.client.get("/api/inspections")
        self.assertEqual(list_resp.status_code, 200)
        ids = [r["inspection_id"] for r in list_resp.get_json()["inspections"]]
        self.assertIn(insp_id, ids)

        get_resp = self.client.get(f"/api/inspections/{insp_id}")
        self.assertEqual(get_resp.status_code, 200)

        del_resp = self.client.delete(f"/api/inspections/{insp_id}")
        self.assertEqual(del_resp.status_code, 200)
        missing_resp = self.client.get(f"/api/inspections/{insp_id}")
        self.assertEqual(missing_resp.status_code, 404)

    def test_report_not_found(self):
        resp = self.client.get("/api/report/NON-EXISTENT-ID")
        self.assertEqual(resp.status_code, 404)

    def test_settings_get_and_post(self):
        resp = self.client.get("/api/settings")
        self.assertEqual(resp.status_code, 200)
        post_resp = self.client.post("/api/settings", json={"confidence_threshold": 0.5})
        self.assertEqual(post_resp.status_code, 200)
        self.assertTrue(post_resp.get_json()["success"])

    def test_inspect_frame_missing_image(self):
        resp = self.client.post("/api/inspect/frame", json={})
        self.assertEqual(resp.status_code, 400)


if __name__ == "__main__":
    unittest.main()
