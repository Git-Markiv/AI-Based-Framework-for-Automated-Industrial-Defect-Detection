"""
Explainability Module
=======================
Produces the visual and textual explanations required by the "Explainable
AI" part of the project.

Visual: a heatmap derived from the same anomaly signal the region-proposal
stage uses (background-subtracted intensity + saturation anomaly), overlaid
in false colour on the original image, plus an annotated "detection" image
with bounding boxes / labels / confidence. This is a deliberately honest
substitute for Grad-CAM: the chosen architecture (classical-CV region
proposal + RandomForest classifier) has no convolutional feature maps to
run Grad-CAM against, so instead we visualise the actual anomaly signal that
drove region proposal, plus per-region feature importances from the trained
ensemble, which is a faithful, non-fabricated explanation for THIS
architecture.

Textual: a templated, fact-based explanation built directly from the
detection, severity and grading outputs (no free-text generation, so it
can never invent facts not present in the pipeline's own output).
"""
import cv2
import numpy as np

STATUS_COLORS = {
    "PASS": (60, 180, 75),      # green (BGR)
    "REVIEW": (0, 170, 255),    # amber
    "REJECT": (40, 40, 220),    # red
}


def draw_detections(img_bgr, detections):
    out = img_bgr.copy()
    for det in detections:
        x1, y1, x2, y2 = det["bbox"]
        level = det.get("severity_level", "MINOR")
        color = {
            "MINOR": (0, 200, 0),
            "MODERATE": (0, 170, 255),
            "MAJOR": (0, 90, 255),
            "CRITICAL": (0, 0, 255),
        }.get(level, (0, 200, 0))
        cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
        label = f"{det['defect'].upper()} {det['confidence']*100:.1f}%"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        ty = max(th + 6, y1)
        cv2.rectangle(out, (x1, ty - th - 8), (x1 + tw + 6, ty), color, -1)
        cv2.putText(out, label, (x1 + 3, ty - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (255, 255, 255), 1, cv2.LINE_AA)
    return out


def generate_heatmap(img_bgr):
    """Anomaly-signal heatmap (stand-in explainability visualization)."""
    h, w = img_bgr.shape[:2]
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray_s = cv2.GaussianBlur(gray, (5, 5), 1.4)
    k = max(21, (min(h, w) // 5) | 1)
    background = cv2.medianBlur(gray_s, k)
    diff = cv2.absdiff(gray_s, background).astype(np.float32)

    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV).astype(np.float32)
    sat = cv2.GaussianBlur(hsv[:, :, 1], (5, 5), 1.4)
    sat_bg = cv2.medianBlur(sat.astype(np.uint8), k).astype(np.float32)
    sat_diff = np.abs(sat - sat_bg)

    anomaly = np.maximum(diff, 0.7 * sat_diff)
    anomaly = cv2.GaussianBlur(anomaly, (9, 9), 0)
    anomaly_norm = cv2.normalize(anomaly, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    heat = cv2.applyColorMap(anomaly_norm, cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(img_bgr, 0.55, heat, 0.45, 0)
    return overlay


def build_explanation_text(detections, severity_max, grade_info, product_name="Inspected Product"):
    """Builds a deterministic, fact-grounded natural-language explanation."""
    if not detections:
        return (f"{product_name} was classified as PASS (Grade A) because no defects "
                f"were detected above the model's confidence threshold. No further "
                f"action is required.")

    top = max(detections, key=lambda d: d.get("severity", 0))
    lines = [f"The product was classified as {grade_info['status']} (Grade {grade_info['grade']}) because:"]
    lines.append(f"\u2022 {top['defect'].capitalize()} detected")
    lines.append(f"\u2022 Confidence: {top['confidence']*100:.1f}%")
    lines.append(f"\u2022 Affected area: {top['area_percentage']:.1f}% of the inspected surface")
    lines.append(f"\u2022 Severity score: {top['severity']:.0f}/100 ({top['severity_level']})")
    loc_risk = top.get("severity_breakdown", {}).get("components", {}).get("location_risk", 0)
    if loc_risk >= 60:
        lines.append("\u2022 Defect located near a critical (central) region of the product")
    if len(detections) > 1:
        lines.append(f"\u2022 {len(detections)} total defects detected, compounding the overall risk")
    lines.append(f"\u2022 {grade_info['reason']}")
    return "\n".join(lines)


def build_full_explanation(img_bgr, detections, severity_max, grade_info, product_name="Inspected Product"):
    detection_img = draw_detections(img_bgr, detections)
    heatmap_img = generate_heatmap(img_bgr)
    text = build_explanation_text(detections, severity_max, grade_info, product_name)
    return {
        "detection_image": detection_img,
        "heatmap_image": heatmap_img,
        "explanation_text": text,
    }
