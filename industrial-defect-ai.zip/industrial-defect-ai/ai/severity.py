"""
Severity Assessment Engine
===========================
Fully transparent, formula-driven severity scoring (0-100). Nothing here is
random - every input to the formula is a measurable property of the
detection(s). Weights and risk tables are read from config.yaml so the
scoring can be re-tuned without code changes.

    Severity Score = area_impact   * w_area
                    + type_risk     * w_type
                    + location_risk * w_location
                    + count_impact  * w_count
                    + confidence    * w_confidence

All five components are pre-normalised to a 0-100 scale before weighting.
"""

DEFAULT_TYPE_RISK = {
    "scratch": 35, "dent": 55, "hole": 80, "crack": 95,
    "corrosion": 65, "discoloration": 20, "normal": 0,
}

DEFAULT_WEIGHTS = {
    "area_impact": 0.35,
    "defect_type_risk": 0.25,
    "location_risk": 0.20,
    "defect_count": 0.10,
    "model_confidence": 0.10,
}


class SeverityEngine:
    def __init__(self, cfg=None):
        cfg = cfg or {}
        self.weights = {**DEFAULT_WEIGHTS, **cfg.get("weights", {})}
        self.type_risk = {**DEFAULT_TYPE_RISK, **cfg.get("defect_type_risk_table", {})}
        self.minor_threshold = cfg.get("minor_threshold", 30)
        self.moderate_threshold = cfg.get("moderate_threshold", 60)
        self.major_threshold = cfg.get("major_threshold", 80)

    def _location_risk(self, bbox, img_w, img_h):
        """Defects nearer the geometric centre of the product are treated as
        higher risk (proxy for "critical structural region"): a scratch near
        an edge is usually less consequential than one through the centre of
        a load-bearing panel."""
        x1, y1, x2, y2 = bbox
        cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
        img_cx, img_cy = img_w / 2.0, img_h / 2.0
        max_dist = ((img_w / 2.0) ** 2 + (img_h / 2.0) ** 2) ** 0.5
        dist = ((cx - img_cx) ** 2 + (cy - img_cy) ** 2) ** 0.5
        closeness = 1.0 - min(1.0, dist / max_dist) if max_dist else 0.0
        return closeness * 100.0

    def score_single(self, detection, img_w, img_h, defect_count=1):
        """Compute severity (0-100) + component breakdown for ONE detection."""
        area_pct = detection.get("area_percentage", 0.0)
        # Area impact: saturate around 25% coverage = 100 risk
        area_impact = min(100.0, (area_pct / 25.0) * 100.0)

        type_risk = self.type_risk.get(detection.get("defect", "normal"), 40)

        location_risk = self._location_risk(detection["bbox"], img_w, img_h)

        # More simultaneous defects on one product = compounding risk,
        # saturating at 5+ defects.
        count_impact = min(100.0, (defect_count / 5.0) * 100.0)

        confidence_component = detection.get("confidence", 0.0) * 100.0

        score = (
            area_impact * self.weights["area_impact"]
            + type_risk * self.weights["defect_type_risk"]
            + location_risk * self.weights["location_risk"]
            + count_impact * self.weights["defect_count"]
            + confidence_component * self.weights["model_confidence"]
        )
        score = round(min(100.0, max(0.0, score)), 1)

        return {
            "score": score,
            "level": self.level_for_score(score),
            "components": {
                "area_impact": round(area_impact, 1),
                "defect_type_risk": round(type_risk, 1),
                "location_risk": round(location_risk, 1),
                "defect_count_impact": round(count_impact, 1),
                "model_confidence": round(confidence_component, 1),
            },
            "weights": self.weights,
        }

    def level_for_score(self, score):
        if score <= 0:
            return "NONE"
        if score < self.minor_threshold:
            return "MINOR"
        if score < self.moderate_threshold:
            return "MODERATE"
        return "MAJOR" if score < self.major_threshold else "CRITICAL"

    def score_all(self, detections, img_w, img_h):
        """Score every detection, return (list_of_scored_detections, max_severity)."""
        n = len(detections)
        scored = []
        for det in detections:
            sev = self.score_single(det, img_w, img_h, defect_count=n)
            merged = {**det, "severity": sev["score"], "severity_level": sev["level"],
                      "severity_breakdown": sev}
            scored.append(merged)
        max_severity = max([d["severity"] for d in scored], default=0.0)
        return scored, max_severity
