"""
Preprocessing Module
=====================
Modular OpenCV-based preprocessing pipeline used before every AI inference
call (image, video frame, or live camera frame). Behaviour is controlled via
config.yaml so it can be tuned without code changes.
"""
import cv2
import numpy as np


class Preprocessor:
    def __init__(self, cfg=None):
        cfg = cfg or {}
        self.resize_w = cfg.get("resize_width", 640)
        self.resize_h = cfg.get("resize_height", 640)
        self.denoise = cfg.get("denoise", True)
        self.use_clahe = cfg.get("clahe", True)
        self.clahe_clip = cfg.get("clahe_clip_limit", 2.5)
        self.clahe_tile = cfg.get("clahe_tile_grid", 8)

    def resize(self, img, keep_aspect=True):
        h, w = img.shape[:2]
        if keep_aspect:
            scale = min(self.resize_w / w, self.resize_h / h)
            nw, nh = int(w * scale), int(h * scale)
            resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_AREA)
            return resized, scale
        resized = cv2.resize(img, (self.resize_w, self.resize_h), interpolation=cv2.INTER_AREA)
        return resized, 1.0

    def denoise_image(self, img):
        return cv2.fastNlMeansDenoisingColored(img, None, 4, 4, 7, 15)

    def apply_clahe(self, img):
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=self.clahe_clip,
                                 tileGridSize=(self.clahe_tile, self.clahe_tile))
        l2 = clahe.apply(l)
        lab2 = cv2.merge((l2, a, b))
        return cv2.cvtColor(lab2, cv2.COLOR_LAB2BGR)

    def run(self, img, resize=True, fast=False):
        """Full pipeline. `fast=True` skips expensive denoising (used for
        live-camera frames so the UI stays responsive)."""
        out = img.copy()
        scale = 1.0
        if resize:
            out, scale = self.resize(out)
        if self.denoise and not fast:
            out = self.denoise_image(out)
        if self.use_clahe:
            out = self.apply_clahe(out)
        return out, scale
