"""
Defect Detector
================
Two-stage, CPU-only detection pipeline:

  Stage 1 - Region proposal: classical computer-vision anomaly segmentation
            (background subtraction via large-kernel blur + edge density +
            color/saturation anomaly) locates candidate defect regions
            without any learned model. This stage plays the role that a
            region-proposal-network plays in a two-stage deep detector.

  Stage 2 - Classification: each candidate region is converted into a
            feature vector (ai/features.py) and classified by the trained
            RandomForest ensemble (ai/training.py) into one of
            {normal, scratch, dent, hole, crack, corrosion, discoloration}.
            The class probability is used directly as the detection
            confidence.

The `Detector` class is intentionally the ONLY class the rest of the
application talks to. Its public interface (`detect(image) -> list[dict]`)
is stable, so a future Ultralytics-YOLO backend could be dropped in as a
drop-in replacement without touching backend/ai callers.
"""
import os
import cv2
import numpy as np
import joblib

from ai.features import extract_region_features

DEFAULT_MODEL_PATH = os.path.join("models", "defectnet_rf.joblib")


def _iou(box_a, box_b):
    ax1, ay1, ax2, ay2 = box_a
    bx1, by1, bx2, by2 = box_b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    area_a = max(0, ax2 - ax1) * max(0, ay2 - ay1)
    area_b = max(0, bx2 - bx1) * max(0, by2 - by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def _nms(detections, iou_thresh=0.35):
    detections = sorted(detections, key=lambda d: d["confidence"], reverse=True)
    keep = []
    for det in detections:
        if all(_iou(det["bbox"], k["bbox"]) < iou_thresh for k in keep):
            keep.append(det)
    return keep


def propose_regions(img_bgr, min_region_area_pct=0.3):
    """Stage-1 region proposal (pure classical CV, no learned model needed).
    Standalone module-level function so it can also be reused by the
    training pipeline to generate the same candidate-region distribution the
    detector will see at inference time (avoids train/inference mismatch).
    """
    h, w = img_bgr.shape[:2]
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    gray_s = cv2.GaussianBlur(gray, (5, 5), 1.4)

    k = max(21, (min(h, w) // 5) | 1)
    background = cv2.medianBlur(gray_s, k)
    diff = cv2.absdiff(gray_s, background)

    hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV).astype(np.float32)
    sat = cv2.GaussianBlur(hsv[:, :, 1], (5, 5), 1.4)
    sat_bg = cv2.medianBlur(sat.astype(np.uint8), k).astype(np.float32)
    sat_diff = np.abs(sat - sat_bg)

    diff_f = diff.astype(np.float32)
    intensity_thr = max(10.0, float(diff_f.mean() + 4.5 * diff_f.std()))
    mask_intensity = (diff_f > intensity_thr).astype(np.uint8) * 255

    sat_thr = max(6.0, float(sat_diff.mean() + 4.5 * sat_diff.std()))
    mask_sat = (sat_diff > sat_thr).astype(np.uint8) * 255

    thresh = cv2.bitwise_or(mask_intensity, mask_sat)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN,
                               np.ones((3, 3), np.uint8), iterations=1)
    thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE,
                               np.ones((9, 9), np.uint8), iterations=2)
    thresh = cv2.dilate(thresh, np.ones((3, 3), np.uint8), iterations=1)

    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    min_area = (min_region_area_pct / 100.0) * (h * w)
    for c in contours:
        area = cv2.contourArea(c)
        if area < min_area:
            continue
        x, y, bw, bh = cv2.boundingRect(c)
        pad = max(2, int(0.08 * max(bw, bh)))
        x1, y1 = max(0, x - pad), max(0, y - pad)
        x2, y2 = min(w - 1, x + bw + pad), min(h - 1, y + bh + pad)
        boxes.append([x1, y1, x2, y2])
    return boxes


class Detector:
    def __init__(self, model_path=DEFAULT_MODEL_PATH, confidence_threshold=0.35,
                 iou_threshold=0.45, min_region_area_pct=0.15):
        self.model_path = model_path
        self.confidence_threshold = confidence_threshold
        self.iou_threshold = iou_threshold
        self.min_region_area_pct = min_region_area_pct
        self._bundle = None
        self.loaded = False
        self.device = "CPU"
        self._load()

    def _load(self):
        if os.path.isfile(self.model_path):
            self._bundle = joblib.load(self.model_path)
            self.loaded = True
        else:
            self.loaded = False

    # ------------------------------------------------------------------
    # Stage 1: region proposal
    # ------------------------------------------------------------------
    def propose_regions(self, img_bgr):
        return propose_regions(img_bgr, self.min_region_area_pct)

    # ------------------------------------------------------------------
    # Stage 2: classification
    # ------------------------------------------------------------------
    def classify_region(self, img_bgr, bbox):
        feats = extract_region_features(img_bgr, bbox)
        if not self.loaded:
            return "normal", 0.0
        model = self._bundle["model"]
        # IMPORTANT: predict_proba's column order follows model.classes_
        # (sklearn sorts labels alphabetically internally) which is NOT
        # necessarily the same order as our human-authored CLASSES list, so
        # we must map indices back via model.classes_, not self._bundle
        # ["classes"].
        probs = model.predict_proba([feats])[0]
        idx = int(np.argmax(probs))
        return model.classes_[idx], float(probs[idx])

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def detect(self, img_bgr):
        """Returns a list of detections:
        {defect, confidence, bbox:[x1,y1,x2,y2], area_percentage}
        Coordinates are in the pixel space of `img_bgr` as given.
        """
        h, w = img_bgr.shape[:2]
        if not self.loaded:
            return []

        candidate_boxes = self.propose_regions(img_bgr)
        detections = []
        for box in candidate_boxes:
            label, conf = self.classify_region(img_bgr, box)
            if label == "normal":
                continue
            if conf < self.confidence_threshold:
                continue
            x1, y1, x2, y2 = box
            area_pct = 100.0 * (x2 - x1) * (y2 - y1) / (h * w)
            detections.append({
                "defect": label,
                "confidence": round(conf, 4),
                "bbox": [int(x1), int(y1), int(x2), int(y2)],
                "area_percentage": round(area_pct, 2),
            })

        detections = _nms(detections, self.iou_threshold)
        detections.sort(key=lambda d: d["confidence"], reverse=True)
        return detections

    def model_info(self):
        info = {
            "loaded": self.loaded,
            "path": self.model_path,
            "device": self.device,
        }
        if self.loaded:
            info["classes"] = self._bundle["classes"]
            info["feature_names"] = self._bundle["feature_names"]
        return info
