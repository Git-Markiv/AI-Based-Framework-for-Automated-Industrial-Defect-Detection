"""
Quality Grading Engine
========================
Maps the maximum severity score (and defect count) of a product to a
quality grade and a PASS / REVIEW / REJECT decision. Thresholds come from
config.yaml so they can be tuned per production line without touching code.
"""

DEFAULT_THRESHOLDS = {"grade_a_max": 20, "grade_b_max": 45, "grade_c_max": 75}


class GradingEngine:
    def __init__(self, cfg=None):
        cfg = cfg or {}
        self.grade_a_max = cfg.get("grade_a_max", DEFAULT_THRESHOLDS["grade_a_max"])
        self.grade_b_max = cfg.get("grade_b_max", DEFAULT_THRESHOLDS["grade_b_max"])
        self.grade_c_max = cfg.get("grade_c_max", DEFAULT_THRESHOLDS["grade_c_max"])

    def grade(self, max_severity, defect_count):
        if defect_count == 0 or max_severity <= 0:
            return {"grade": "A", "status": "PASS",
                    "reason": "No defects detected above the confidence threshold."}

        if max_severity <= self.grade_a_max:
            return {"grade": "A", "status": "PASS",
                    "reason": f"Highest severity ({max_severity}/100) is negligible."}
        if max_severity <= self.grade_b_max:
            return {"grade": "B", "status": "PASS",
                    "reason": f"Minor defect(s) detected (severity {max_severity}/100); "
                              "does not significantly affect usability."}
        if max_severity <= self.grade_c_max:
            return {"grade": "C", "status": "REVIEW",
                    "reason": f"Significant defect(s) detected (severity {max_severity}/100); "
                              "product requires manual review / rework."}
        return {"grade": "REJECT", "status": "REJECT",
                "reason": f"Severity ({max_severity}/100) exceeds the rejection threshold "
                          f"({self.grade_c_max}); defect is major/critical or structurally significant."}
