"""
Feature Extraction
===================
Converts a candidate image region (bbox) into a fixed-length numeric feature
vector used by the classical-CV + ML classifier. Kept in one place so
training and inference always use identical features.
"""
import cv2
import numpy as np

FEATURE_NAMES = [
    "area_pct", "aspect_ratio", "extent", "mean_intensity", "std_intensity",
    "bg_diff", "edge_density", "circularity", "mean_hue", "mean_sat",
    "colorfulness", "grad_mean", "darkness_ratio",
]


def _safe_div(a, b, default=0.0):
    return a / b if b not in (0, 0.0) else default


def extract_region_features(img_bgr, bbox):
    """img_bgr: full image (BGR). bbox: [x1,y1,x2,y2] in image pixel coords."""
    h, w = img_bgr.shape[:2]
    x1, y1, x2, y2 = [int(v) for v in bbox]
    x1, y1 = max(0, x1), max(0, y1)
    x2, y2 = min(w - 1, max(x2, x1 + 1)), min(h - 1, max(y2, y1 + 1))
    region = img_bgr[y1:y2, x1:x2]
    if region.size == 0:
        return np.zeros(len(FEATURE_NAMES), dtype=np.float32)

    rh, rw = region.shape[:2]
    area_pct = 100.0 * (rw * rh) / (w * h)
    aspect_ratio = _safe_div(max(rw, rh), max(1, min(rw, rh)))

    gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
    mean_intensity = float(np.mean(gray))
    std_intensity = float(np.std(gray))

    # local background = ring around the bbox, expanded by 40%
    pad_x, pad_y = int(rw * 0.4) + 2, int(rh * 0.4) + 2
    bx1, by1 = max(0, x1 - pad_x), max(0, y1 - pad_y)
    bx2, by2 = min(w, x2 + pad_x), min(h, y2 + pad_y)
    outer = img_bgr[by1:by2, bx1:bx2]
    outer_gray = cv2.cvtColor(outer, cv2.COLOR_BGR2GRAY)
    bg_mean = float(np.mean(outer_gray)) if outer_gray.size else mean_intensity
    bg_diff = abs(mean_intensity - bg_mean)

    edges = cv2.Canny(gray, 50, 150)
    edge_density = float(np.mean(edges > 0))

    # circularity via largest contour in region
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    circularity = 0.0
    extent = 0.0
    if contours:
        c = max(contours, key=cv2.contourArea)
        area = cv2.contourArea(c)
        perim = cv2.arcLength(c, True)
        if perim > 0:
            circularity = float(4 * np.pi * area / (perim ** 2))
        extent = _safe_div(area, rw * rh)

    hsv = cv2.cvtColor(region, cv2.COLOR_BGR2HSV)
    mean_hue = float(np.mean(hsv[:, :, 0]))
    mean_sat = float(np.mean(hsv[:, :, 1]))

    b, g, r = cv2.split(region.astype(np.float32))
    rg = r - g
    yb = 0.5 * (r + g) - b
    colorfulness = float(np.sqrt(np.std(rg) ** 2 + np.std(yb) ** 2) +
                          0.3 * np.sqrt(np.mean(rg) ** 2 + np.mean(yb) ** 2))

    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0)
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1)
    grad_mag = np.sqrt(gx ** 2 + gy ** 2)
    grad_mean = float(np.mean(grad_mag))

    darkness_ratio = _safe_div(mean_intensity, bg_mean if bg_mean else 1.0)

    feats = np.array([
        area_pct, aspect_ratio, extent, mean_intensity, std_intensity,
        bg_diff, edge_density, circularity, mean_hue, mean_sat,
        colorfulness, grad_mean, darkness_ratio,
    ], dtype=np.float32)
    feats = np.nan_to_num(feats, nan=0.0, posinf=0.0, neginf=0.0)
    return feats
