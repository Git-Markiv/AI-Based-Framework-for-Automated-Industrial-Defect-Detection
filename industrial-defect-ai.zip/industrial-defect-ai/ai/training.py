"""
Training Script
================
Trains the DefectNet classifier: a RandomForest ensemble operating on
hand-engineered computer-vision features extracted from candidate regions.

This is a CPU-friendly, dependency-light "classical CV + ML" architecture
chosen because this environment has no GPU / deep-learning framework
available. The code is written so a YOLO (Ultralytics) detector backend can
be swapped in later (see ai/detector.py `Detector` interface) without
touching the rest of the application.

Honesty note: metrics reported here are REAL, computed on a held-out test
split of the SYNTHETIC DEMONSTRATION DATASET. They are not representative of
real-world industrial deployment performance.
"""
import os
import json
import time
import numpy as np
import cv2
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support, accuracy_score

from ai.features import extract_region_features, FEATURE_NAMES
from ai.detector import propose_regions, _iou

CLASSES = ["normal", "scratch", "dent", "hole", "crack", "corrosion", "discoloration"]


def _random_background_box(w, h, rng, exclude_boxes=None, size_range=(20, 70)):
    exclude_boxes = exclude_boxes or []
    for _ in range(15):
        bw = rng.randint(size_range[0], size_range[1])
        bh = rng.randint(size_range[0], size_range[1])
        x1 = rng.randint(0, max(1, w - bw))
        y1 = rng.randint(0, max(1, h - bh))
        box = [x1, y1, x1 + bw, y1 + bh]
        overlaps = False
        for eb in exclude_boxes:
            ix1, iy1 = max(box[0], eb[0]), max(box[1], eb[1])
            ix2, iy2 = min(box[2], eb[2]), min(box[3], eb[3])
            if ix2 > ix1 and iy2 > iy1:
                overlaps = True
                break
        if not overlaps:
            return box
    return [0, 0, min(w - 1, size_range[1]), min(h - 1, size_range[1])]


def build_training_table(data_root, min_region_area_pct=0.3, pos_iou_thresh=0.2):
    """Builds the (features, label) training table using the SAME classical-CV
    region-proposal stage the detector uses at inference time (ai/detector.py
    `propose_regions`). Each proposed candidate region is labeled by its best
    IoU overlap with the ground-truth defect boxes; regions with no
    sufficient overlap (including proposals triggered by lighting/texture
    noise) are labeled "normal". Training on this exact distribution -
    instead of only on idealised ground-truth boxes - is what lets the
    classifier correctly reject noisy candidate regions at inference time.
    """
    meta_path = os.path.join(data_root, "metadata", "dataset.json")
    with open(meta_path) as f:
        meta = json.load(f)
    records = meta["records"]

    X, y, groups = [], [], []
    rng = np.random.RandomState(7)

    for rec in records:
        img_path = os.path.join(data_root, rec["path"])
        img = cv2.imread(img_path)
        if img is None:
            continue
        h, w = img.shape[:2]
        gt_boxes = rec["defects"]

        # Also include the exact ground-truth boxes themselves as strong
        # positive examples (helps the classifier learn a clean prototype
        # for each defect class in addition to noisier proposal boxes).
        used_boxes = []
        for d in gt_boxes:
            feats = extract_region_features(img, d["bbox"])
            X.append(feats)
            y.append(d["label"])
            groups.append(rec["split"])
            used_boxes.append(d["bbox"])

        proposals = propose_regions(img, min_region_area_pct=min_region_area_pct)
        for box in proposals:
            best_label, best_iou = "normal", 0.0
            for d in gt_boxes:
                iou = _iou(box, d["bbox"])
                if iou > best_iou:
                    best_iou, best_label = iou, d["label"]
            label = best_label if best_iou >= pos_iou_thresh else "normal"
            feats = extract_region_features(img, box)
            X.append(feats)
            y.append(label)
            groups.append(rec["split"])
            used_boxes.append(box)

        # a couple of clean random-background negatives too, for balance
        n_neg = 2 if rec["is_normal"] else 1
        for _ in range(n_neg):
            box = _random_background_box(w, h, rng, exclude_boxes=used_boxes)
            feats = extract_region_features(img, box)
            X.append(feats)
            y.append("normal")
            groups.append(rec["split"])

    return np.array(X), np.array(y), np.array(groups)


def train_model(data_root="data", models_dir="models", progress_cb=None):
    os.makedirs(models_dir, exist_ok=True)
    if progress_cb:
        progress_cb("Extracting features from dataset...", 10)
    X, y, groups = build_training_table(data_root)

    train_mask = groups == "train"
    val_mask = groups == "val"
    test_mask = groups == "test"

    X_train, y_train = X[train_mask], y[train_mask]
    X_test, y_test = X[test_mask | val_mask], y[test_mask | val_mask]

    if progress_cb:
        progress_cb("Training RandomForest ensemble...", 40)

    clf = RandomForestClassifier(
        n_estimators=250,
        max_depth=14,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=42,
        n_jobs=1,  # NOTE: intentionally single-threaded. Using n_jobs=-1 lets
        # joblib fork worker processes, which can crash or hang when predict()
        # is later called from inside a Flask request-handling thread in
        # sandboxed / restricted-fork environments. A single feature vector
        # prediction is cheap enough that parallelism buys nothing anyway.
    )
    t0 = time.time()
    clf.fit(X_train, y_train)
    train_time = time.time() - t0

    if progress_cb:
        progress_cb("Evaluating model...", 80)

    y_pred = clf.predict(X_test)
    acc = float(accuracy_score(y_test, y_pred))
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_test, y_pred, average="macro", zero_division=0
    )

    metrics = {
        "accuracy": round(acc, 4),
        "precision_macro": round(float(precision), 4),
        "recall_macro": round(float(recall), 4),
        "f1_macro": round(float(f1), 4),
        "n_train_samples": int(len(X_train)),
        "n_test_samples": int(len(X_test)),
        "train_time_seconds": round(train_time, 2),
        "classes": CLASSES,
        "feature_names": FEATURE_NAMES,
        "trained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "note": "Metrics computed on held-out split of the SYNTHETIC DEMONSTRATION DATASET. "
                "Not representative of real-world industrial performance.",
    }

    model_path = os.path.join(models_dir, "defectnet_rf.joblib")
    joblib.dump({"model": clf, "classes": CLASSES, "feature_names": FEATURE_NAMES}, model_path)

    with open(os.path.join(models_dir, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)

    if progress_cb:
        progress_cb("Model saved.", 100)

    return metrics


def model_exists(models_dir="models"):
    return os.path.isfile(os.path.join(models_dir, "defectnet_rf.joblib"))


if __name__ == "__main__":
    m = train_model()
    print(json.dumps(m, indent=2))
